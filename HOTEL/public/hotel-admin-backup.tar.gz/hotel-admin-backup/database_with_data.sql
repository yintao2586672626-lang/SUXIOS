-- 多酒店管理系统数据库（含数据）
-- 导出时间: 2026-02-24 17:56:37

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for daily_reports
-- ----------------------------
DROP TABLE IF EXISTS `daily_reports`;
CREATE TABLE `daily_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `report_date` date NOT NULL,
  `report_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `occupancy_rate` decimal(5,2) DEFAULT NULL,
  `room_count` int DEFAULT '0',
  `guest_count` int DEFAULT '0',
  `revenue` decimal(12,2) DEFAULT '0.00',
  `expenses` decimal(12,2) DEFAULT '0.00',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `submitter_id` int DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_hotel_date` (`hotel_id`,`report_date`),
  CONSTRAINT `daily_reports_chk_1` CHECK (json_valid(`report_data`))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for daily_reports
-- ----------------------------
INSERT INTO `daily_reports` VALUES ('1', '1', '2026-02-23', '{\"occupancy_rate\":85.5,\"total_rooms_sold\":50,\"total_revenue\":15000}', NULL, '0', '0', '0.00', '0.00', NULL, '1', '2', '2026-02-24 09:20:50', '2026-02-24 09:20:50');

-- ----------------------------
-- Table structure for hotels
-- ----------------------------
DROP TABLE IF EXISTS `hotels`;
CREATE TABLE `hotels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_person` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `description` text COLLATE utf8mb4_unicode_ci,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for hotels
-- ----------------------------
INSERT INTO `hotels` VALUES ('1', '东方大酒店', 'DF001', '北京市朝阳区', '张经理', '010-12345678', '1', NULL, '2026-02-24 09:15:46', '2026-02-24 09:15:46');
INSERT INTO `hotels` VALUES ('2', '西湖度假村', 'XH002', '杭州市西湖区', '李经理', '0571-87654321', '1', NULL, '2026-02-24 09:15:46', '2026-02-24 09:15:46');
INSERT INTO `hotels` VALUES ('3', '海滨国际酒店', 'HB003', '上海市浦东新区', '王经理', '021-11112222', '1', NULL, '2026-02-24 09:15:46', '2026-02-24 09:15:46');

-- ----------------------------
-- Table structure for monthly_tasks
-- ----------------------------
DROP TABLE IF EXISTS `monthly_tasks`;
CREATE TABLE `monthly_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `task_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `revenue_target` decimal(12,2) DEFAULT '0.00',
  `occupancy_target` decimal(5,2) DEFAULT '0.00',
  `guest_target` int DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `submitter_id` int DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_hotel_month` (`hotel_id`,`year`,`month`),
  CONSTRAINT `monthly_tasks_chk_1` CHECK (json_valid(`task_data`))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for monthly_tasks
-- ----------------------------
INSERT INTO `monthly_tasks` VALUES ('1', '1', '2026', '3', '{\"occupancy_rate_target\":85,\"ota_total_orders\":200,\"revenue_budget\":500000}', '0.00', '0.00', '0', NULL, '1', '1', '2026-02-24 09:20:41', '2026-02-24 09:20:41');
INSERT INTO `monthly_tasks` VALUES ('2', '1', '2026', '2', '{\"occupancy_rate_target\":80,\"ota_total_orders\":180,\"revenue_budget\":400000}', '0.00', '0.00', '0', NULL, '1', '1', '2026-02-24 09:20:50', '2026-02-24 09:20:50');

-- ----------------------------
-- Table structure for online_daily_data
-- ----------------------------
DROP TABLE IF EXISTS `online_daily_data`;
CREATE TABLE `online_daily_data` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` varchar(50) NOT NULL COMMENT '酒店ID',
  `hotel_name` varchar(255) NOT NULL COMMENT '酒店名称',
  `data_date` date NOT NULL COMMENT '数据日期',
  `amount` decimal(12,2) DEFAULT '0.00' COMMENT '营业额',
  `quantity` int DEFAULT '0' COMMENT '离店间夜',
  `book_order_num` int DEFAULT '0' COMMENT '预定数',
  `comment_score` decimal(3,1) DEFAULT '0.0' COMMENT '点评分',
  `qunar_comment_score` decimal(3,1) DEFAULT '0.0' COMMENT '去哪儿点评分',
  `raw_data` text COMMENT '原始JSON数据',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_hotel_date` (`hotel_id`,`data_date`),
  KEY `idx_data_date` (`data_date`),
  KEY `idx_hotel_id` (`hotel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='线上每日数据表';

-- ----------------------------
-- Data for online_daily_data
-- ----------------------------
INSERT INTO `online_daily_data` VALUES ('1', '1009378', '好时代酒店（南宁金象大道地铁站店）', '2026-02-23', '2522.00', '22', '12', '4.8', '4.9', '{\"hotelId\":1009378,\"hotelName\":\"好时代酒店（南宁金象大道地铁站店）\",\"amount\":2522,\"quantity\":22,\"bookOrderNum\":12,\"commentScore\":4.8,\"totalDetailNum\":29,\"convertionRate\":17.24,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":17,\"qunarDetailCR\":0,\"amountRank\":9,\"quantityRank\":5,\"bookOrderNumRank\":10,\"commentScoreRank\":1,\"totalDetailNumRank\":5,\"convertionRateRank\":4,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":9,\"qunarDetailCRRank\":16}', '2026-02-24 16:54:45', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('2', '1009378', '好时代酒店（南宁金象大道地铁站店）', '2026-02-22', '2850.00', '25', '15', '4.7', '4.8', '{\"hotelId\":1009378}', '2026-02-24 16:54:45', '2026-02-24 16:54:45');
INSERT INTO `online_daily_data` VALUES ('3', '1009379', '测试酒店A', '2026-02-23', '3522.00', '30', '18', '4.9', '4.9', '{\"hotelId\":1009379}', '2026-02-24 16:54:45', '2026-02-24 16:54:45');
INSERT INTO `online_daily_data` VALUES ('4', '1009380', '测试酒店B', '2026-02-23', '1522.00', '12', '8', '4.5', '4.6', '{\"hotelId\":1009380}', '2026-02-24 16:54:45', '2026-02-24 16:54:45');
INSERT INTO `online_daily_data` VALUES ('5', '974065', '亚里酒店(南宁江南车站万达广场店)', '2026-02-23', '3280.00', '16', '24', '4.4', '4.9', '{\"hotelId\":974065,\"hotelName\":\"亚里酒店(南宁江南车站万达广场店)\",\"amount\":3280,\"quantity\":16,\"bookOrderNum\":24,\"commentScore\":4.4,\"totalDetailNum\":41,\"convertionRate\":0,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":37,\"qunarDetailCR\":2.7,\"amountRank\":8,\"quantityRank\":9,\"bookOrderNumRank\":2,\"commentScoreRank\":15,\"totalDetailNumRank\":2,\"convertionRateRank\":15,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":3,\"qunarDetailCRRank\":14}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('6', '988280', '红灯笼商务酒店（南宁大沙田地铁站店）', '2026-02-23', '1782.39', '15', '16', '4.6', '4.9', '{\"hotelId\":988280,\"hotelName\":\"红灯笼商务酒店（南宁大沙田地铁站店）\",\"amount\":1782.3899999999999,\"quantity\":15,\"bookOrderNum\":16,\"commentScore\":4.6,\"totalDetailNum\":6,\"convertionRate\":16.67,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":13,\"qunarDetailCR\":0,\"amountRank\":15,\"quantityRank\":10,\"bookOrderNumRank\":5,\"commentScoreRank\":12,\"totalDetailNumRank\":20,\"convertionRateRank\":5,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":12,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('7', '1098077', '南宁多一天精品酒店(江南客运站地铁站店）', '2026-02-23', '0.00', '0', '0', '4.3', '4.9', '{\"hotelId\":1098077,\"hotelName\":\"南宁多一天精品酒店(江南客运站地铁站店）\",\"amount\":0,\"quantity\":0,\"bookOrderNum\":0,\"commentScore\":4.3,\"totalDetailNum\":0,\"convertionRate\":0,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":0,\"qunarDetailCR\":0,\"amountRank\":21,\"quantityRank\":21,\"bookOrderNumRank\":22,\"commentScoreRank\":20,\"totalDetailNumRank\":22,\"convertionRateRank\":15,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":22,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('8', '1221618', '7天连锁酒店(南宁江南客运站地铁口店)', '2026-02-23', '7137.00', '57', '28', '4.5', '4.3', '{\"hotelId\":1221618,\"hotelName\":\"7天连锁酒店(南宁江南客运站地铁口店)\",\"amount\":7137,\"quantity\":57,\"bookOrderNum\":28,\"commentScore\":4.5,\"totalDetailNum\":35,\"convertionRate\":11.43,\"qunarCommentScore\":4.3,\"qunarDetailVisitors\":30,\"qunarDetailCR\":13.33,\"amountRank\":2,\"quantityRank\":1,\"bookOrderNumRank\":1,\"commentScoreRank\":13,\"totalDetailNumRank\":4,\"convertionRateRank\":9,\"qunarCommentScoreRank\":23,\"qunarDetailVisitorsRank\":4,\"qunarDetailCRRank\":6}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('9', '1376748', '逸喆酒店(南宁石子塘地铁站店)', '2026-02-23', '4717.00', '31', '14', '4.7', '4.9', '{\"hotelId\":1376748,\"hotelName\":\"逸喆酒店(南宁石子塘地铁站店)\",\"amount\":4717,\"quantity\":31,\"bookOrderNum\":14,\"commentScore\":4.7,\"totalDetailNum\":38,\"convertionRate\":13.16,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":19,\"qunarDetailCR\":5.26,\"amountRank\":4,\"quantityRank\":3,\"bookOrderNumRank\":7,\"commentScoreRank\":10,\"totalDetailNumRank\":3,\"convertionRateRank\":6,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":8,\"qunarDetailCRRank\":10}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('10', '1407551', '好友酒店（南宁金象大道地铁站店）', '2026-02-23', '837.00', '7', '9', '4.7', '4.9', '{\"hotelId\":1407551,\"hotelName\":\"好友酒店（南宁金象大道地铁站店）\",\"amount\":837,\"quantity\":7,\"bookOrderNum\":9,\"commentScore\":4.7,\"totalDetailNum\":10,\"convertionRate\":0,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":5,\"qunarDetailCR\":20,\"amountRank\":19,\"quantityRank\":18,\"bookOrderNumRank\":13,\"commentScoreRank\":7,\"totalDetailNumRank\":14,\"convertionRateRank\":15,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":20,\"qunarDetailCRRank\":2}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('11', '1413989', '雅斯特酒店（南宁五象新区金象大道地铁站店）', '2026-02-23', '0.00', '0', '0', '4.4', '4.9', '{\"hotelId\":1413989,\"hotelName\":\"雅斯特酒店（南宁五象新区金象大道地铁站店）\",\"amount\":0,\"quantity\":0,\"bookOrderNum\":0,\"commentScore\":4.4,\"totalDetailNum\":0,\"convertionRate\":0,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":0,\"qunarDetailCR\":0,\"amountRank\":21,\"quantityRank\":21,\"bookOrderNumRank\":22,\"commentScoreRank\":17,\"totalDetailNumRank\":22,\"convertionRateRank\":15,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":22,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('12', '1630499', '枫景澜庭酒店(南宁大沙田建设路地铁站店)', '2026-02-23', '1294.00', '8', '13', '4.5', '4.8', '{\"hotelId\":1630499,\"hotelName\":\"枫景澜庭酒店(南宁大沙田建设路地铁站店)\",\"amount\":1294,\"quantity\":8,\"bookOrderNum\":13,\"commentScore\":4.5,\"totalDetailNum\":18,\"convertionRate\":5.56,\"qunarCommentScore\":4.8,\"qunarDetailVisitors\":20,\"qunarDetailCR\":20,\"amountRank\":18,\"quantityRank\":16,\"bookOrderNumRank\":8,\"commentScoreRank\":14,\"totalDetailNumRank\":8,\"convertionRateRank\":13,\"qunarCommentScoreRank\":17,\"qunarDetailVisitorsRank\":7,\"qunarDetailCRRank\":2}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('13', '1685042', '我的酒店', '2026-02-23', '3307.84', '22', '17', '4.7', '4.9', '{\"hotelId\":1685042,\"hotelName\":\"我的酒店\",\"amount\":3307.84,\"quantity\":22,\"bookOrderNum\":17,\"commentScore\":4.7,\"totalDetailNum\":17,\"convertionRate\":0,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":13,\"qunarDetailCR\":30.77,\"amountRank\":6,\"quantityRank\":5,\"bookOrderNumRank\":3,\"commentScoreRank\":3,\"totalDetailNumRank\":9,\"convertionRateRank\":15,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":12,\"qunarDetailCRRank\":1}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('14', '1721937', '城市便捷酒店(南宁大沙田地铁站店)', '2026-02-23', '1852.00', '8', '8', '4.7', '4.9', '{\"hotelId\":1721937,\"hotelName\":\"城市便捷酒店(南宁大沙田地铁站店)\",\"amount\":1852,\"quantity\":8,\"bookOrderNum\":8,\"commentScore\":4.7,\"totalDetailNum\":17,\"convertionRate\":17.65,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":14,\"qunarDetailCR\":7.14,\"amountRank\":13,\"quantityRank\":16,\"bookOrderNumRank\":15,\"commentScoreRank\":3,\"totalDetailNumRank\":9,\"convertionRateRank\":3,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":11,\"qunarDetailCRRank\":9}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('15', '2888038', '星月酒店（江南客运站大沙田地铁站店）', '2026-02-23', '1990.00', '12', '8', '4.4', '4.8', '{\"hotelId\":2888038,\"hotelName\":\"星月酒店（江南客运站大沙田地铁站店）\",\"amount\":1990,\"quantity\":12,\"bookOrderNum\":8,\"commentScore\":4.4,\"totalDetailNum\":14,\"convertionRate\":0,\"qunarCommentScore\":4.8,\"qunarDetailVisitors\":132,\"qunarDetailCR\":1.52,\"amountRank\":12,\"quantityRank\":14,\"bookOrderNumRank\":15,\"commentScoreRank\":18,\"totalDetailNumRank\":12,\"convertionRateRank\":15,\"qunarCommentScoreRank\":17,\"qunarDetailVisitorsRank\":1,\"qunarDetailCRRank\":15}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('16', '3054798', '贝壳酒店（南宁金象大道地铁站店）', '2026-02-23', '0.00', '0', '3', '4.0', '4.8', '{\"hotelId\":3054798,\"hotelName\":\"贝壳酒店（南宁金象大道地铁站店）\",\"amount\":0,\"quantity\":0,\"bookOrderNum\":3,\"commentScore\":4,\"totalDetailNum\":8,\"convertionRate\":0,\"qunarCommentScore\":4.8,\"qunarDetailVisitors\":5,\"qunarDetailCR\":0,\"amountRank\":21,\"quantityRank\":21,\"bookOrderNumRank\":21,\"commentScoreRank\":22,\"totalDetailNumRank\":17,\"convertionRateRank\":15,\"qunarCommentScoreRank\":17,\"qunarDetailVisitorsRank\":20,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('17', '4826364', '南宁二三角酒店（大沙田金象大道地铁站店）', '2026-02-23', '1839.36', '14', '11', '4.4', '4.9', '{\"hotelId\":4826364,\"hotelName\":\"南宁二三角酒店（大沙田金象大道地铁站店）\",\"amount\":1839.3600000000001,\"quantity\":14,\"bookOrderNum\":11,\"commentScore\":4.4,\"totalDetailNum\":10,\"convertionRate\":10,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":8,\"qunarDetailCR\":0,\"amountRank\":14,\"quantityRank\":11,\"bookOrderNumRank\":12,\"commentScoreRank\":19,\"totalDetailNumRank\":14,\"convertionRateRank\":12,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":15,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('18', '5079562', '柏怡酒店(南宁大沙田地铁站店)', '2026-02-23', '2049.00', '13', '12', '4.7', '4.9', '{\"hotelId\":5079562,\"hotelName\":\"柏怡酒店(南宁大沙田地铁站店)\",\"amount\":2049,\"quantity\":13,\"bookOrderNum\":12,\"commentScore\":4.7,\"totalDetailNum\":16,\"convertionRate\":12.5,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":44,\"qunarDetailCR\":4.55,\"amountRank\":11,\"quantityRank\":13,\"bookOrderNumRank\":10,\"commentScoreRank\":7,\"totalDetailNumRank\":11,\"convertionRateRank\":7,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":2,\"qunarDetailCRRank\":11}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('19', '6783466', '聚满楼酒店（南宁五象新区金象大道地铁站店）', '2026-02-23', '2271.00', '14', '9', '4.1', '4.6', '{\"hotelId\":6783466,\"hotelName\":\"聚满楼酒店（南宁五象新区金象大道地铁站店）\",\"amount\":2271,\"quantity\":14,\"bookOrderNum\":9,\"commentScore\":4.1,\"totalDetailNum\":10,\"convertionRate\":0,\"qunarCommentScore\":4.6,\"qunarDetailVisitors\":7,\"qunarDetailCR\":14.29,\"amountRank\":10,\"quantityRank\":11,\"bookOrderNumRank\":13,\"commentScoreRank\":21,\"totalDetailNumRank\":14,\"convertionRateRank\":15,\"qunarCommentScoreRank\":21,\"qunarDetailVisitorsRank\":16,\"qunarDetailCRRank\":4}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('20', '15899563', '维也纳智好酒店(体育中心大沙田地铁站店)', '2026-02-23', '6183.00', '26', '17', '4.7', '4.9', '{\"hotelId\":15899563,\"hotelName\":\"维也纳智好酒店(体育中心大沙田地铁站店)\",\"amount\":6183,\"quantity\":26,\"bookOrderNum\":17,\"commentScore\":4.7,\"totalDetailNum\":76,\"convertionRate\":10.53,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":23,\"qunarDetailCR\":4.35,\"amountRank\":3,\"quantityRank\":4,\"bookOrderNumRank\":3,\"commentScoreRank\":11,\"totalDetailNumRank\":1,\"convertionRateRank\":11,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":5,\"qunarDetailCRRank\":12}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('21', '28067759', '雅斯特酒店(南宁五象石子塘地铁站店)', '2026-02-23', '1602.00', '7', '4', '4.4', '4.8', '{\"hotelId\":28067759,\"hotelName\":\"雅斯特酒店(南宁五象石子塘地铁站店)\",\"amount\":1602,\"quantity\":7,\"bookOrderNum\":4,\"commentScore\":4.4,\"totalDetailNum\":8,\"convertionRate\":12.5,\"qunarCommentScore\":4.8,\"qunarDetailVisitors\":7,\"qunarDetailCR\":0,\"amountRank\":16,\"quantityRank\":18,\"bookOrderNumRank\":19,\"commentScoreRank\":15,\"totalDetailNumRank\":17,\"convertionRateRank\":7,\"qunarCommentScoreRank\":17,\"qunarDetailVisitorsRank\":16,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('22', '40795187', '傲金酒店(南宁大沙田地铁站店)', '2026-02-23', '362.00', '2', '4', '3.9', '4.9', '{\"hotelId\":40795187,\"hotelName\":\"傲金酒店(南宁大沙田地铁站店)\",\"amount\":362,\"quantity\":2,\"bookOrderNum\":4,\"commentScore\":3.9,\"totalDetailNum\":1,\"convertionRate\":0,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":7,\"qunarDetailCR\":14.29,\"amountRank\":20,\"quantityRank\":20,\"bookOrderNumRank\":19,\"commentScoreRank\":23,\"totalDetailNumRank\":21,\"convertionRateRank\":15,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":16,\"qunarDetailCRRank\":4}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('23', '50468388', '逸喆酒店(南宁大沙田建设路地铁站店)', '2026-02-23', '3282.00', '21', '13', '4.7', '4.9', '{\"hotelId\":50468388,\"hotelName\":\"逸喆酒店(南宁大沙田建设路地铁站店)\",\"amount\":3282,\"quantity\":21,\"bookOrderNum\":13,\"commentScore\":4.7,\"totalDetailNum\":21,\"convertionRate\":4.76,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":7,\"qunarDetailCR\":0,\"amountRank\":7,\"quantityRank\":7,\"bookOrderNumRank\":8,\"commentScoreRank\":7,\"totalDetailNumRank\":7,\"convertionRateRank\":14,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":16,\"qunarDetailCRRank\":16}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('24', '73665061', '璟曼酒店（南宁江南客运站大沙田地铁站店)', '2026-02-23', '9541.00', '49', '16', '4.7', '4.9', '{\"hotelId\":73665061,\"hotelName\":\"璟曼酒店（南宁江南客运站大沙田地铁站店)\",\"amount\":9541,\"quantity\":49,\"bookOrderNum\":16,\"commentScore\":4.7,\"totalDetailNum\":27,\"convertionRate\":11.11,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":23,\"qunarDetailCR\":4.35,\"amountRank\":1,\"quantityRank\":2,\"bookOrderNumRank\":5,\"commentScoreRank\":6,\"totalDetailNumRank\":6,\"convertionRateRank\":10,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":5,\"qunarDetailCRRank\":12}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('25', '76423370', '维也纳酒店(南宁江南客运站店)', '2026-02-23', '4056.14', '17', '7', '4.7', '4.6', '{\"hotelId\":76423370,\"hotelName\":\"维也纳酒店(南宁江南客运站店)\",\"amount\":4056.1400000000003,\"quantity\":17,\"bookOrderNum\":7,\"commentScore\":4.7,\"totalDetailNum\":11,\"convertionRate\":27.27,\"qunarCommentScore\":4.6,\"qunarDetailVisitors\":17,\"qunarDetailCR\":11.76,\"amountRank\":5,\"quantityRank\":8,\"bookOrderNumRank\":17,\"commentScoreRank\":3,\"totalDetailNumRank\":13,\"convertionRateRank\":1,\"qunarCommentScoreRank\":21,\"qunarDetailVisitorsRank\":9,\"qunarDetailCRRank\":7}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');
INSERT INTO `online_daily_data` VALUES ('26', '105011011', '南宁沙田见酒店（大沙田建设路地铁站店）', '2026-02-23', '1560.36', '10', '6', '4.8', '4.9', '{\"hotelId\":105011011,\"hotelName\":\"南宁沙田见酒店（大沙田建设路地铁站店）\",\"amount\":1560.3600000000001,\"quantity\":10,\"bookOrderNum\":6,\"commentScore\":4.8,\"totalDetailNum\":8,\"convertionRate\":25,\"qunarCommentScore\":4.9,\"qunarDetailVisitors\":9,\"qunarDetailCR\":11.11,\"amountRank\":17,\"quantityRank\":15,\"bookOrderNumRank\":18,\"commentScoreRank\":2,\"totalDetailNumRank\":17,\"convertionRateRank\":2,\"qunarCommentScoreRank\":1,\"qunarDetailVisitorsRank\":14,\"qunarDetailCRRank\":8}', '2026-02-24 17:54:09', '2026-02-24 17:54:09');

-- ----------------------------
-- Table structure for operation_logs
-- ----------------------------
DROP TABLE IF EXISTS `operation_logs`;
CREATE TABLE `operation_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for operation_logs
-- ----------------------------
INSERT INTO `operation_logs` VALUES ('1', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:19:20');
INSERT INTO `operation_logs` VALUES ('2', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:24');
INSERT INTO `operation_logs` VALUES ('3', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:32');
INSERT INTO `operation_logs` VALUES ('4', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:40');
INSERT INTO `operation_logs` VALUES ('5', '1', 'monthly_task', 'create', '创建月任务: 2026年3月', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:41');
INSERT INTO `operation_logs` VALUES ('6', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:50');
INSERT INTO `operation_logs` VALUES ('7', '1', 'monthly_task', 'create', '创建月任务: 2026年2月', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:50');
INSERT INTO `operation_logs` VALUES ('8', '1', 'daily_report', 'create', '创建日报表: 2026-02-23', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:20:50');
INSERT INTO `operation_logs` VALUES ('9', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 09:36:38');
INSERT INTO `operation_logs` VALUES ('10', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 16:08:24');
INSERT INTO `operation_logs` VALUES ('11', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 16:15:05');
INSERT INTO `operation_logs` VALUES ('13', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 16:53:35');
INSERT INTO `operation_logs` VALUES ('14', '1', 'online_data', 'fetch_ctrip', '获取携程线上数据', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-24 16:57:04');
INSERT INTO `operation_logs` VALUES ('15', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 16:59:42');
INSERT INTO `operation_logs` VALUES ('16', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 17:02:07');
INSERT INTO `operation_logs` VALUES ('17', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 17:07:03');
INSERT INTO `operation_logs` VALUES ('18', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 17:08:50');
INSERT INTO `operation_logs` VALUES ('19', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-24 17:22:36');
INSERT INTO `operation_logs` VALUES ('20', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 17:33:10');
INSERT INTO `operation_logs` VALUES ('21', '1', 'auth', 'login', '用户登录: admin', '127.0.0.1', 'curl/8.5.0', '2026-02-24 17:33:13');
INSERT INTO `operation_logs` VALUES ('22', '1', 'online_data', 'toggle_auto_fetch', '切换自动获取状态: 开启', '127.0.0.1', 'curl/8.5.0', '2026-02-24 17:33:47');
INSERT INTO `operation_logs` VALUES ('23', '1', 'online_data', 'fetch_ctrip', '获取携程线上数据', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36 Edg/145.0.0.0', '2026-02-24 17:54:09');

-- ----------------------------
-- Table structure for report_configs
-- ----------------------------
DROP TABLE IF EXISTS `report_configs`;
CREATE TABLE `report_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `report_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'number',
  `category` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT '基础信息',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int DEFAULT '0',
  `is_required` tinyint DEFAULT '0',
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_report_field` (`report_type`,`field_name`)
) ENGINE=InnoDB AUTO_INCREMENT=161 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for report_configs
-- ----------------------------
INSERT INTO `report_configs` VALUES ('80', 'monthly', 'revenue_budget', '营业预算', 'number', '月任务数据填写', '元', NULL, '1', '1', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('81', 'monthly', 'ota_total_orders', 'OTA总单量', 'number', '月任务数据填写', '单', NULL, '2', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('82', 'monthly', 'gold_card_sales', '金卡销售月任务', 'number', '月任务数据填写', '张', NULL, '3', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('83', 'monthly', 'black_gold_sales', '黑金卡销售月任务', 'number', '月任务数据填写', '张', NULL, '4', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('84', 'monthly', 'meituan_scan_target', '美团扫码目标', 'number', '月任务数据填写', '次', NULL, '5', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('85', 'monthly', 'salable_rooms_total', '可售房间总数', 'number', '月任务数据填写', '间', NULL, '6', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('86', 'monthly', 'occupancy_rate_target', '出租率', 'number', '月任务数据填写', '%', NULL, '7', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('87', 'monthly', 'revpar', '单房收益RP', 'number', '月任务数据填写', '元', NULL, '8', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('88', 'monthly', 'new_members', '新会员数', 'number', '月任务数据填写', '人', NULL, '9', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('89', 'monthly', 'wechat_new_friends', '酒店号新加微信好友数', 'number', '月任务数据填写', '人', NULL, '10', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('90', 'monthly', 'wechat_revenue', '微信成交额', 'number', '月任务数据填写', '元', NULL, '11', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('91', 'monthly', 'new_contracts', '新签协议', 'number', '月任务数据填写', '份', NULL, '12', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('92', 'monthly', 'good_review_rate', '好评率', 'number', '月任务数据填写', '%', NULL, '13', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('93', 'monthly', 'online_revenue_target', '线上营收目标', 'number', '月任务数据填写', '元', NULL, '14', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('94', 'monthly', 'offline_revenue_target', '线下营收目标', 'number', '月任务数据填写', '元', NULL, '15', '0', '1', '2026-02-24 09:19:08', '2026-02-24 09:19:08');
INSERT INTO `report_configs` VALUES ('95', 'daily', 'salable_rooms', '当天可售房数', 'number', '一、当天基础数据填写', '间', NULL, '1', '1', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('96', 'daily', 'overnight_rooms', '过夜房间数', 'number', '一、当天基础数据填写', '间', NULL, '2', '1', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('97', 'daily', 'xb_revenue', '携程房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '3', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('98', 'daily', 'xb_rooms', '携程出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '4', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('99', 'daily', 'mt_revenue', '美团房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '5', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('100', 'daily', 'mt_rooms', '美团出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '6', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('101', 'daily', 'fliggy_revenue', '飞猪房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '7', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('102', 'daily', 'fliggy_rooms', '飞猪出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '8', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('103', 'daily', 'dy_revenue', '抖音房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '9', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('104', 'daily', 'dy_rooms', '抖音出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '10', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('105', 'daily', 'tc_revenue', '同程房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '11', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('106', 'daily', 'tc_rooms', '同程出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '12', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('107', 'daily', 'qn_revenue', '去哪儿房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '13', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('108', 'daily', 'qn_rooms', '去哪儿出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '14', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('109', 'daily', 'zx_revenue', '智行房费收入', 'number', '二、线上OTA数据填写', '元', NULL, '15', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('110', 'daily', 'zx_rooms', '智行出租间夜', 'number', '二、线上OTA数据填写', '间', NULL, '16', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('111', 'daily', 'walkin_revenue', '散客房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '17', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('112', 'daily', 'walkin_rooms', '散客出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '18', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('113', 'daily', 'member_exp_revenue', '会员体验房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '19', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('114', 'daily', 'member_exp_rooms', '会员体验间夜', 'number', '三、线下渠道数据填写', '间', NULL, '20', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('115', 'daily', 'web_exp_revenue', '网络体验房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '21', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('116', 'daily', 'web_exp_rooms', '网络体验出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '22', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('117', 'daily', 'group_revenue', '团队房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '23', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('118', 'daily', 'group_rooms', '团队出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '24', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('119', 'daily', 'protocol_revenue', '协议客户房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '25', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('120', 'daily', 'protocol_rooms', '协议客户出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '26', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('121', 'daily', 'wechat_revenue', '微信房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '27', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('122', 'daily', 'wechat_rooms', '微信出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '28', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('123', 'daily', 'free_revenue', '免费房房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '29', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('124', 'daily', 'free_rooms', '免费房出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '30', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('125', 'daily', 'gold_card_revenue', '集团金卡房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '31', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('126', 'daily', 'gold_card_rooms', '集团金卡出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '32', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('127', 'daily', 'black_gold_revenue', '集团黑金卡房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '33', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('128', 'daily', 'black_gold_rooms', '集团黑金卡出租间夜', 'number', '三、线下渠道数据填写', '间', NULL, '34', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('129', 'daily', 'hourly_revenue', '钟点房房费收入', 'number', '三、线下渠道数据填写', '元', NULL, '35', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('130', 'daily', 'hourly_rooms', '钟点房间夜', 'number', '三、线下渠道数据填写', '间', NULL, '36', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('131', 'daily', 'parking_revenue', '停车费用收入', 'number', '四、其它收入数据填写', '元', NULL, '37', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('132', 'daily', 'dining_revenue', '餐饮费用收入', 'number', '四、其它收入数据填写', '元', NULL, '38', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('133', 'daily', 'meeting_revenue', '会议活动费用收入', 'number', '四、其它收入数据填写', '元', NULL, '39', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('134', 'daily', 'goods_revenue', '商品费用收入', 'number', '四、其它收入数据填写', '元', NULL, '40', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('135', 'daily', 'member_card_revenue', '会员卡费收入', 'number', '四、其它收入数据填写', '元', NULL, '41', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('136', 'daily', 'other_revenue', '其他费用收入', 'number', '四、其它收入数据填写', '元', NULL, '42', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('137', 'daily', 'xb_reviewable', '携程可评价订单数', 'number', '五、OTA点评数据填写', '单', NULL, '43', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('138', 'daily', 'xb_good_review', '携程好评数量', 'number', '五、OTA点评数据填写', '条', NULL, '44', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('139', 'daily', 'xb_bad_review', '携程差评数', 'number', '五、OTA点评数据填写', '条', NULL, '45', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('140', 'daily', 'mt_reviewable', '美团可评价订单数', 'number', '五、OTA点评数据填写', '单', NULL, '46', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('141', 'daily', 'mt_good_review', '美团好评数量', 'number', '五、OTA点评数据填写', '条', NULL, '47', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('142', 'daily', 'mt_bad_review', '美团差评数', 'number', '五、OTA点评数据填写', '条', NULL, '48', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('143', 'daily', 'fliggy_reviewable', '飞猪可评价订单数', 'number', '五、OTA点评数据填写', '单', NULL, '49', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('144', 'daily', 'fliggy_good_review', '飞猪好评数量', 'number', '五、OTA点评数据填写', '条', NULL, '50', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('145', 'daily', 'fliggy_bad_review', '飞猪差评数', 'number', '五、OTA点评数据填写', '条', NULL, '51', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('146', 'daily', 'xb_exposure', '携程列表页曝光量', 'number', '六、OTA流量数据填写', '次', NULL, '52', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('147', 'daily', 'xb_detail_view', '携程详情页浏览量', 'number', '六、OTA流量数据填写', '次', NULL, '53', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('148', 'daily', 'xb_order_view', '携程订单页浏览量', 'number', '六、OTA流量数据填写', '次', NULL, '54', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('149', 'daily', 'xb_order_submit', '携程订单提交量', 'number', '六、OTA流量数据填写', '次', NULL, '55', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('150', 'daily', 'mt_exposure', '美团曝光人数', 'number', '六、OTA流量数据填写', '人', NULL, '56', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('151', 'daily', 'mt_view', '美团浏览人数', 'number', '六、OTA流量数据填写', '人', NULL, '57', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('152', 'daily', 'mt_online_order', '美团线上支付单数', 'number', '六、OTA流量数据填写', '单', NULL, '58', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('153', 'daily', 'wechat_add', '微信加粉', 'number', '七、私域流量数据填写', '人', NULL, '59', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('154', 'daily', 'member_card_sold', '会员卡售卡数量', 'number', '七、私域流量数据填写', '张', NULL, '60', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('155', 'daily', 'private_revenue', '私域订单房费收入', 'number', '七、私域流量数据填写', '元', NULL, '61', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('156', 'daily', 'private_rooms', '私域订单间夜', 'number', '七、私域流量数据填写', '间', NULL, '62', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('157', 'daily', 'stored_value', '储值收入', 'number', '七、私域流量数据填写', '元', NULL, '63', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('158', 'daily', 'damei_card_count', '大美卡数量', 'number', '八、大美卡数据填写', '张', NULL, '64', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('159', 'daily', 'cash_income', '今日现金收入', 'number', '八、大美卡数据填写', '元', NULL, '65', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');
INSERT INTO `report_configs` VALUES ('160', 'daily', 'tomorrow_booking', '明日预订数量', 'number', '九、明日预订数据填写', '间', NULL, '66', '0', '1', '2026-02-24 09:34:21', '2026-02-24 09:34:21');

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `level` int DEFAULT '0',
  `permissions` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for roles
-- ----------------------------
INSERT INTO `roles` VALUES ('1', 'super_admin', '超级管理员', '拥有系统所有权限，可管理所有酒店', '1', '[\"all\"]', '1', '2026-02-24 09:15:46', '2026-02-24 09:15:46');
INSERT INTO `roles` VALUES ('2', 'hotel_manager', '门店管理员', '管理指定酒店，可查看、填写、编辑报表', '2', '[\"hotel_view\",\"report_view\",\"report_fill\",\"report_edit\",\"report_delete\"]', '1', '2026-02-24 09:15:46', '2026-02-24 09:15:46');
INSERT INTO `roles` VALUES ('3', 'hotel_staff', '店员', '只能填写指定酒店的报表', '3', '[\"report_view\",\"report_fill\"]', '1', '2026-02-24 09:15:46', '2026-02-24 09:15:46');

-- ----------------------------
-- Table structure for system_configs
-- ----------------------------
DROP TABLE IF EXISTS `system_configs`;
CREATE TABLE `system_configs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `config_key` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config_value` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `config_key` (`config_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for user_hotel_permissions
-- ----------------------------
DROP TABLE IF EXISTS `user_hotel_permissions`;
CREATE TABLE `user_hotel_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `hotel_id` int NOT NULL,
  `can_view_report` tinyint DEFAULT '0',
  `can_fill_daily_report` tinyint DEFAULT '0',
  `can_fill_monthly_task` tinyint DEFAULT '0',
  `can_edit_report` tinyint DEFAULT '0',
  `can_delete_report` tinyint DEFAULT '0',
  `is_primary` tinyint DEFAULT '0',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_hotel` (`user_id`,`hotel_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for user_hotel_permissions
-- ----------------------------
INSERT INTO `user_hotel_permissions` VALUES ('1', '2', '1', '1', '1', '1', '1', '1', '1', '2026-02-24 09:15:47', '2026-02-24 09:15:47');
INSERT INTO `user_hotel_permissions` VALUES ('2', '3', '1', '1', '1', '1', '0', '0', '0', '2026-02-24 09:15:47', '2026-02-24 09:15:47');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `realname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int DEFAULT '3',
  `status` tinyint DEFAULT '1',
  `hotel_id` int DEFAULT NULL,
  `last_login_time` datetime DEFAULT NULL,
  `last_login_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Data for users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'admin', '$2y$10$NOSHgTq9zo6su1.g0q03mudxD20r0IrfrHVNiztZHjzDEkiu0fWGS', '超级管理员', NULL, NULL, '1', '1', NULL, '2026-02-24 17:33:13', '127.0.0.1', '2026-02-24 09:15:46', '2026-02-24 17:33:13');
INSERT INTO `users` VALUES ('2', 'manager1', '$2y$10$cRx3Eg71/S/STD/.Y7WQ9.r9muB12zXsMI/4MSbBQWQcmzPhqwNGm', '东方酒店经理', NULL, NULL, '2', '1', '1', NULL, NULL, '2026-02-24 09:15:47', '2026-02-24 09:15:47');
INSERT INTO `users` VALUES ('3', 'staff1', '$2y$10$gBq8/il7IxxIfGMXw9YVY.cUCp8tpBE2uSBwQpzGbPfvUbct2Etzu', '前台员工', NULL, NULL, '3', '1', '1', NULL, NULL, '2026-02-24 09:15:47', '2026-02-24 09:15:47');

SET FOREIGN_KEY_CHECKS = 1;
