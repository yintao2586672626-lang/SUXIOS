# 多酒店管理系统

## 项目说明
基于 ThinkPHP 8.1 开发的多酒店管理后台系统

## 目录结构
```
├── app/                    # 应用目录
│   ├── controller/         # 控制器
│   ├── model/              # 模型
│   ├── middleware/         # 中间件
│   └── ...
├── config/                 # 配置文件
├── route/                  # 路由定义
├── public/                 # 公共文件（入口、前端）
├── scripts/                # 脚本文件
├── database.sql            # 数据库结构（不含数据）
├── database_with_data.sql  # 数据库结构+示例数据
└── README.md               # 本文件
```

## 安装步骤

### 1. 环境要求
- PHP 8.0+
- MySQL 5.7+
- Composer

### 2. 安装依赖
```bash
composer install
```

### 3. 导入数据库
```bash
mysql -u root -p your_database < database.sql
# 或导入带示例数据的版本
mysql -u root -p your_database < database_with_data.sql
```

### 4. 配置环境变量
复制 `.example.env` 为 `.env` 并修改数据库配置

### 5. 运行项目
```bash
php think run
```

## 默认账号
- 超级管理员: admin / admin123
- 门店管理员: manager1 / manager123
- 店员: staff1 / staff123

## 功能模块
- 酒店管理
- 用户与权限管理
- 日报表管理
- 月任务管理
- 线上数据获取与展示
- 系统配置
