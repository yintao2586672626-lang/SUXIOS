<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
use think\facade\Route;

// CORS 预检请求
Route::options('api/:any', function() {
    return response('', 204);
})->pattern(['any' => '.*']);

// ==================== 认证路由 ====================
// 登录不需要认证
Route::post('api/auth/login', 'Auth/login');

// 以下认证路由需要登录
Route::group('api/auth', function () {
    Route::post('logout', 'Auth/logout');
    Route::get('info', 'Auth/info');
    Route::post('changePassword', 'Auth/changePassword');
})->middleware(\app\middleware\Auth::class);

// ==================== 酒店管理路由 ====================
Route::group('api/hotels', function () {
    Route::get('/', 'Hotel/index');
    Route::get('/all', 'Hotel/all');
    Route::get('/:id', 'Hotel/read');
    Route::post('/', 'Hotel/create');
    Route::put('/:id', 'Hotel/update');
    Route::delete('/:id', 'Hotel/delete');
})->middleware(\app\middleware\Auth::class);

// ==================== 用户管理路由 ====================
Route::group('api/users', function () {
    Route::get('/', 'User/index');
    Route::get('/roles', 'User/roles');
    // 注意：更具体的路由放在前面，避免被通用的 :id 路由匹配
    Route::get('/:id/permissions', 'User/permissions');
    Route::put('/:id/permissions', 'User/updatePermissions');
    Route::get('/:id', 'User/read');
    Route::post('/', 'User/create');
    Route::put('/:id', 'User/update');
    Route::delete('/:id', 'User/delete');
})->middleware(\app\middleware\Auth::class);

// ==================== 日报表路由 ====================
Route::group('api/daily-reports', function () {
    Route::get('/config', 'DailyReport/config');
    Route::get('/export', 'DailyReport/export');
    Route::get('/', 'DailyReport/index');
    Route::get('/:id/detail', 'DailyReport/detail');
    Route::get('/:id', 'DailyReport/read');
    Route::post('/', 'DailyReport/create');
    Route::put('/:id', 'DailyReport/update');
    Route::delete('/:id', 'DailyReport/delete');
})->middleware(\app\middleware\Auth::class);

// ==================== 月任务路由 ====================
Route::group('api/monthly-tasks', function () {
    Route::get('/config', 'MonthlyTask/config');
    Route::get('/', 'MonthlyTask/index');
    Route::get('/:id', 'MonthlyTask/read');
    Route::post('/', 'MonthlyTask/create');
    Route::put('/:id', 'MonthlyTask/update');
    Route::delete('/:id', 'MonthlyTask/delete');
})->middleware(\app\middleware\Auth::class);

// ==================== 报表配置路由 ====================
Route::group('api/report-configs', function () {
    Route::get('/', 'ReportConfig/index');
    Route::get('/all', 'ReportConfig/all');
    Route::get('/:id', 'ReportConfig/read');
    Route::post('/', 'ReportConfig/create');
    Route::put('/:id', 'ReportConfig/update');
    Route::delete('/:id', 'ReportConfig/delete');
})->middleware(\app\middleware\Auth::class);

// ==================== 系统配置路由 ====================
Route::group('api/system-config', function () {
    Route::get('/', 'SystemConfigController/index');
    Route::put('/', 'SystemConfigController/update');
})->middleware(\app\middleware\Auth::class);

// ==================== 线上数据获取路由 ====================
Route::group('api/online-data', function () {
    Route::post('/fetch-ctrip', 'OnlineData/fetchCtrip');
    Route::post('/fetch-custom', 'OnlineData/fetchCustom');
    Route::post('/save-cookies', 'OnlineData/saveCookies');
    Route::get('/cookies-list', 'OnlineData/getCookiesList');
    Route::post('/delete-cookies', 'OnlineData/deleteCookies');
    Route::get('/bookmarklet', 'OnlineData/bookmarklet');
    // 线上数据管理
    Route::post('/save-daily-data', 'OnlineData/saveDailyData');
    Route::get('/daily-data-list', 'OnlineData/dailyDataList');
    Route::get('/daily-data-summary', 'OnlineData/dailyDataSummary');
    Route::get('/hotel-list', 'OnlineData/hotelList');
    Route::get('/auto-fetch', 'OnlineData/autoFetch');
    Route::get('/auto-fetch-status', 'OnlineData/autoFetchStatus');
    Route::post('/toggle-auto-fetch', 'OnlineData/toggleAutoFetch');
})->middleware(\app\middleware\Auth::class);

// 接收书签脚本的Cookies（不需要认证中间件，通过token参数验证）
Route::post('api/online-data/receive-cookies', 'OnlineData/receiveCookies');
Route::options('api/online-data/receive-cookies', 'OnlineData/receiveCookies');

// 健康检查
Route::get('api/health', function () {
    return json(['status' => 'ok', 'time' => date('Y-m-d H:i:s')]);
});
