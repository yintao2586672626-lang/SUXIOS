<?php
declare(strict_types=1);

namespace app\model;

use think\Model;

/**
 * 系统配置模型
 */
class SystemConfig extends Model
{
    // 表名
    protected $name = 'system_configs';

    // 自动时间戳
    protected $autoWriteTimestamp = true;
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';

    // 配置键常量
    const KEY_SYSTEM_NAME = 'system_name';
    const KEY_LOGO_URL = 'logo_url';
    const KEY_MENU_HOTEL = 'menu_hotel_name';
    const KEY_MENU_USERS = 'menu_users_name';
    const KEY_MENU_DAILY_REPORT = 'menu_daily_report_name';
    const KEY_MENU_MONTHLY_TASK = 'menu_monthly_task_name';
    const KEY_MENU_REPORT_CONFIG = 'menu_report_config_name';

    /**
     * 获取配置值
     */
    public static function getValue(string $key, $default = null)
    {
        $config = self::where('config_key', $key)->find();
        return $config ? $config->config_value : $default;
    }

    /**
     * 设置配置值
     */
    public static function setValue(string $key, $value, string $description = ''): bool
    {
        $config = self::where('config_key', $key)->find();
        if ($config) {
            $config->config_value = $value;
            return $config->save();
        } else {
            $config = new self();
            $config->config_key = $key;
            $config->config_value = $value;
            $config->description = $description;
            return $config->save();
        }
    }

    /**
     * 获取所有配置
     */
    public static function getAllConfigs(): array
    {
        $configs = self::select();
        $result = [];
        foreach ($configs as $config) {
            $result[$config->config_key] = $config->config_value;
        }
        return $result;
    }

    /**
     * 获取默认配置
     */
    public static function getDefaultConfigs(): array
    {
        return [
            self::KEY_SYSTEM_NAME => '酒店管理系统',
            self::KEY_LOGO_URL => '',
            self::KEY_MENU_HOTEL => '酒店管理',
            self::KEY_MENU_USERS => '用户管理',
            self::KEY_MENU_DAILY_REPORT => '日报表管理',
            self::KEY_MENU_MONTHLY_TASK => '月任务管理',
            self::KEY_MENU_REPORT_CONFIG => '报表配置',
        ];
    }
}
