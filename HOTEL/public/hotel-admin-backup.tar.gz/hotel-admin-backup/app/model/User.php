<?php
declare(strict_types=1);

namespace app\model;

use think\Model;

class User extends Model
{
    protected $name = 'users';
    
    protected $autoWriteTimestamp = true;
    
    protected $createTime = 'create_time';
    protected $updateTime = 'update_time';
    
    protected $type = [
        'id' => 'integer',
        'status' => 'integer',
        'hotel_id' => 'integer',
        'role_id' => 'integer',
    ];

    // 隐藏字段
    protected $hidden = ['password'];

    // 状态常量
    const STATUS_ENABLED = 1;
    const STATUS_DISABLED = 0;

    /**
     * 关联角色
     */
    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }

    /**
     * 关联主酒店
     */
    public function hotel()
    {
        return $this->belongsTo(Hotel::class, 'hotel_id', 'id');
    }

    /**
     * 关联用户酒店权限
     */
    public function hotelPermissions()
    {
        return $this->hasMany(UserHotelPermission::class, 'user_id', 'id');
    }

    /**
     * 密码修改器
     */
    public function setPasswordAttr($value)
    {
        return password_hash($value, PASSWORD_DEFAULT);
    }

    /**
     * 验证密码
     */
    public function verifyPassword(string $password): bool
    {
        return password_verify($password, $this->password);
    }

    /**
     * 是否是超级管理员
     */
    public function isSuperAdmin(): bool
    {
        return $this->role_id == 1;
    }

    /**
     * 是否是门店管理员
     */
    public function isHotelManager(): bool
    {
        return $this->role_id == 2;
    }

    /**
     * 是否是店员
     */
    public function isStaff(): bool
    {
        return $this->role_id == 3;
    }

    /**
     * 获取角色名称
     */
    public function getRoleName(): string
    {
        $role = $this->role;
        return $role ? $role->display_name : '未知';
    }

    /**
     * 检查是否有某个酒店的权限
     */
    public function hasHotelPermission(int $hotelId, string $permission): bool
    {
        if ($this->isSuperAdmin()) {
            return true;
        }

        $perm = UserHotelPermission::where('user_id', $this->id)
            ->where('hotel_id', $hotelId)
            ->find();

        if (!$perm) {
            return false;
        }

        return $perm->$permission == 1;
    }

    /**
     * 获取用户有权限的酒店ID列表
     */
    public function getPermittedHotelIds(): array
    {
        if ($this->isSuperAdmin()) {
            return Hotel::column('id');
        }

        return UserHotelPermission::where('user_id', $this->id)
            ->column('hotel_id');
    }

    /**
     * 获取用户在某个酒店的权限
     */
    public function getHotelPermission(int $hotelId): ?UserHotelPermission
    {
        return UserHotelPermission::where('user_id', $this->id)
            ->where('hotel_id', $hotelId)
            ->find();
    }
}
