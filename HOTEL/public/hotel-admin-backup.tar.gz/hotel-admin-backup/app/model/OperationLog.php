<?php
declare(strict_types=1);

namespace app\model;

use think\Model;

class OperationLog extends Model
{
    protected $name = 'operation_logs';
    
    protected $autoWriteTimestamp = true;
    protected $createTime = 'create_time';
    protected $updateTime = false;
    
    protected $type = [
        'id' => 'integer',
        'user_id' => 'integer',
    ];

    /**
     * 记录日志
     */
    public static function record(string $module, string $action, string $description, int $userId = null)
    {
        $log = new self();
        $log->user_id = $userId;
        $log->module = $module;
        $log->action = $action;
        $log->description = $description;
        $log->ip = request()->ip();
        $log->user_agent = request()->header('user-agent', '');
        $log->save();
        
        return $log;
    }
}
