<?php
declare(strict_types=1);

namespace app\controller;

use app\model\DailyReport as DailyReportModel;
use app\model\MonthlyTask;
use app\model\Hotel;
use app\model\OperationLog;
use think\exception\ValidateException;
use think\Response;
use think\facade\Db;

class DailyReport extends Base
{
    /**
     * 获取报表配置
     */
    public function config(): Response
    {
        $this->checkPermission();
        
        // 获取日报表配置，按分类分组
        $configs = Db::table('report_configs')
            ->where('report_type', 'daily')
            ->where('status', 1)
            ->order('sort_order', 'asc')
            ->select()
            ->toArray();
        
        // 按分类分组
        $groupedConfigs = [];
        foreach ($configs as $config) {
            $category = $config['category'];
            if (!isset($groupedConfigs[$category])) {
                $groupedConfigs[$category] = [
                    'category' => $category,
                    'items' => []
                ];
            }
            $groupedConfigs[$category]['items'][] = [
                'id' => $config['id'],
                'field_name' => $config['field_name'],
                'display_name' => $config['display_name'],
                'field_type' => $config['field_type'],
                'unit' => $config['unit'],
                'sort_order' => $config['sort_order'],
                'is_required' => $config['is_required'],
            ];
        }
        
        // 转为索引数组
        $result = array_values($groupedConfigs);
        
        return $this->success($result);
    }

    /**
     * 日报表列表
     */
    public function index(): Response
    {
        $this->checkPermission();

        $pagination = $this->getPagination();
        $hotelId = $this->request->param('hotel_id', '');
        $startDate = $this->request->param('start_date', '');
        $endDate = $this->request->param('end_date', '');

        $query = DailyReportModel::with(['hotel', 'submitter'])->order('id', 'desc');

        // 根据权限过滤酒店
        if (!$this->currentUser->isSuperAdmin()) {
            $permittedHotelIds = $this->currentUser->getPermittedHotelIds();
            if (empty($permittedHotelIds)) {
                return $this->paginate([], 0, $pagination['page'], $pagination['page_size']);
            }
            if ($hotelId && in_array($hotelId, $permittedHotelIds)) {
                $query->where('hotel_id', $hotelId);
            } else {
                $query->whereIn('hotel_id', $permittedHotelIds);
            }
        } elseif ($hotelId) {
            $query->where('hotel_id', $hotelId);
        }

        if ($startDate && $endDate) {
            $query->whereBetween('report_date', [$startDate, $endDate]);
        } elseif ($startDate) {
            $query->where('report_date', '>=', $startDate);
        } elseif ($endDate) {
            $query->where('report_date', '<=', $endDate);
        }

        $total = $query->count();
        $list = $query->page($pagination['page'], $pagination['page_size'])->select();

        return $this->paginate($list, $total, $pagination['page'], $pagination['page_size']);
    }

    /**
     * 日报表详情（基础）
     */
    public function read(int $id): Response
    {
        $this->checkPermission();

        $report = DailyReportModel::with(['hotel', 'submitter'])->find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_view_report')) {
            return $this->error('无权查看此报表');
        }

        return $this->success($report);
    }

    /**
     * 日报表查看详情（带计算数据）
     */
    public function detail(int $id): Response
    {
        $this->checkPermission();

        $report = DailyReportModel::with(['hotel'])->find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_view_report')) {
            return $this->error('无权查看此报表');
        }

        $hotel = $report->hotel;
        $reportData = $report->report_data ?? [];
        $reportDate = $report->report_date;
        
        // 获取年月
        $dateParts = explode('-', $reportDate);
        $year = (int)$dateParts[0];
        $month = (int)$dateParts[1];
        $day = (int)$dateParts[2];
        
        // 获取当月天数
        $monthDays = (int)date('t', strtotime($reportDate));
        
        // 获取月任务
        $monthlyTask = MonthlyTask::where('hotel_id', $report->hotel_id)
            ->where('year', $year)
            ->where('month', $month)
            ->find();
        $taskData = $monthlyTask ? ($monthlyTask->task_data ?? []) : [];
        
        // 获取当月所有日报表数据（用于计算月累计）
        $monthReports = DailyReportModel::where('hotel_id', $report->hotel_id)
            ->where('report_date', '>=', "{$year}-{$month}-01")
            ->where('report_date', '<=', $reportDate)
            ->select();
        
        // 计算月累计数据
        $monthSum = $this->calculateMonthSum($monthReports);
        
        // 计算各项指标
        $result = $this->calculateReportDetail($hotel, $reportData, $taskData, $monthSum, $reportDate, $day, $monthDays);
        
        return $this->success($result);
    }
    
    /**
     * 计算月累计数据
     */
    private function calculateMonthSum($reports): array
    {
        $sum = [];
        foreach ($reports as $report) {
            $data = $report->report_data ?? [];
            foreach ($data as $key => $value) {
                if (!isset($sum[$key])) {
                    $sum[$key] = 0;
                }
                if (is_numeric($value)) {
                    $sum[$key] += $value;
                }
            }
        }
        return $sum;
    }
    
    /**
     * 计算报表详情数据
     */
    private function calculateReportDetail($hotel, $reportData, $taskData, $monthSum, $reportDate, $day, $monthDays): array
    {
        // 辅助函数：安全获取数值
        $getVal = function($data, $key, $default = 0) {
            return isset($data[$key]) && is_numeric($data[$key]) ? (float)$data[$key] : $default;
        };
        
        // 酒店房间数（需要从酒店信息或配置获取，这里先默认）
        $totalRooms = $getVal($taskData, 'salable_rooms_total', 59); // 可售房间总数
        
        // ==================== 一、销售业绩 ====================
        
        // OTA收入
        $xbRevenue = $getVal($reportData, 'xb_revenue');
        $mtRevenue = $getVal($reportData, 'mt_revenue');
        $fliggyRevenue = $getVal($reportData, 'fliggy_revenue');
        $dyRevenue = $getVal($reportData, 'dy_revenue');
        $tcRevenue = $getVal($reportData, 'tc_revenue');
        $qnRevenue = $getVal($reportData, 'qn_revenue');
        $zxRevenue = $getVal($reportData, 'zx_revenue');
        
        // 线下收入
        $walkinRevenue = $getVal($reportData, 'walkin_revenue');
        $memberExpRevenue = $getVal($reportData, 'member_exp_revenue');
        $webExpRevenue = $getVal($reportData, 'web_exp_revenue');
        $groupRevenue = $getVal($reportData, 'group_revenue');
        $protocolRevenue = $getVal($reportData, 'protocol_revenue');
        $wechatRevenue = $getVal($reportData, 'wechat_revenue');
        $freeRevenue = $getVal($reportData, 'free_revenue');
        $goldCardRevenue = $getVal($reportData, 'gold_card_revenue');
        $blackGoldRevenue = $getVal($reportData, 'black_gold_revenue');
        $hourlyRevenue = $getVal($reportData, 'hourly_revenue');
        
        // 其他收入
        $parkingRevenue = $getVal($reportData, 'parking_revenue');
        $diningRevenue = $getVal($reportData, 'dining_revenue');
        $meetingRevenue = $getVal($reportData, 'meeting_revenue');
        $goodsRevenue = $getVal($reportData, 'goods_revenue');
        $memberCardRevenue = $getVal($reportData, 'member_card_revenue');
        $otherRevenue = $getVal($reportData, 'other_revenue');
        
        // OTA间夜
        $xbRooms = $getVal($reportData, 'xb_rooms');
        $mtRooms = $getVal($reportData, 'mt_rooms');
        $fliggyRooms = $getVal($reportData, 'fliggy_rooms');
        $dyRooms = $getVal($reportData, 'dy_rooms');
        $tcRooms = $getVal($reportData, 'tc_rooms');
        $qnRooms = $getVal($reportData, 'qn_rooms');
        $zxRooms = $getVal($reportData, 'zx_rooms');
        
        // 线下间夜
        $walkinRooms = $getVal($reportData, 'walkin_rooms');
        $memberExpRooms = $getVal($reportData, 'member_exp_rooms');
        $webExpRooms = $getVal($reportData, 'web_exp_rooms');
        $groupRooms = $getVal($reportData, 'group_rooms');
        $protocolRooms = $getVal($reportData, 'protocol_rooms');
        $wechatRooms = $getVal($reportData, 'wechat_rooms');
        $freeRooms = $getVal($reportData, 'free_rooms');
        $goldCardRooms = $getVal($reportData, 'gold_card_rooms');
        $blackGoldRooms = $getVal($reportData, 'black_gold_rooms');
        $hourlyRooms = $getVal($reportData, 'hourly_rooms');
        
        // 基础数据
        $salableRooms = $getVal($reportData, 'salable_rooms', $totalRooms);
        $overnightRooms = $getVal($reportData, 'overnight_rooms', 0);
        
        // 私域数据
        $wechatAdd = $getVal($reportData, 'wechat_add');
        $memberCardSold = $getVal($reportData, 'member_card_sold');
        $privateRevenue = $getVal($reportData, 'private_revenue');
        $privateRooms = $getVal($reportData, 'private_rooms');
        $storedValue = $getVal($reportData, 'stored_value');
        
        // 大美卡
        $dameiCardCount = $getVal($reportData, 'damei_card_count');
        $cashIncome = $getVal($reportData, 'cash_income');
        
        // 明日预订
        $tomorrowBooking = $getVal($reportData, 'tomorrow_booking');
        
        // OTA点评
        $xbReviewable = $getVal($reportData, 'xb_reviewable');
        $xbGoodReview = $getVal($reportData, 'xb_good_review');
        $xbBadReview = $getVal($reportData, 'xb_bad_review');
        $mtReviewable = $getVal($reportData, 'mt_reviewable');
        $mtGoodReview = $getVal($reportData, 'mt_good_review');
        $mtBadReview = $getVal($reportData, 'mt_bad_review');
        $fliggyReviewable = $getVal($reportData, 'fliggy_reviewable');
        $fliggyGoodReview = $getVal($reportData, 'fliggy_good_review');
        $fliggyBadReview = $getVal($reportData, 'fliggy_bad_review');
        
        // ===== 日计算数据 =====
        
        // 日线上总收入 = 所有OTA收入
        $dayOnlineRevenue = $xbRevenue + $mtRevenue + $fliggyRevenue + $dyRevenue + $tcRevenue + $qnRevenue + $zxRevenue;
        
        // 日线下总收入
        $dayOfflineRevenue = $walkinRevenue + $memberExpRevenue + $webExpRevenue + $groupRevenue + 
                             $protocolRevenue + $wechatRevenue + $freeRevenue + $goldCardRevenue + 
                             $blackGoldRevenue + $hourlyRevenue;
        
        // 日其他收入
        $dayOtherRevenue = $parkingRevenue + $diningRevenue + $meetingRevenue + $goodsRevenue + $memberCardRevenue + $otherRevenue;
        
        // 日房费总收入 = 线上 + 线下
        $dayRoomRevenue = $dayOnlineRevenue + $dayOfflineRevenue;
        
        // 日总营收 = 房费 + 其他
        $dayTotalRevenue = $dayRoomRevenue + $dayOtherRevenue;
        
        // 日出租总间数
        $dayTotalRooms = $xbRooms + $mtRooms + $fliggyRooms + $dyRooms + $tcRooms + $qnRooms + $zxRooms +
                        $walkinRooms + $memberExpRooms + $webExpRooms + $groupRooms + 
                        $protocolRooms + $wechatRooms + $freeRooms + $goldCardRooms + $blackGoldRooms;
        
        // 日过夜房间数
        $dayOvernightRooms = $overnightRooms > 0 ? $overnightRooms : $dayTotalRooms;
        
        // 日综合出租率 = (日出租总间数 / 可售房间数) * 100
        $dayOccRate = $salableRooms > 0 ? round(($dayTotalRooms / $salableRooms) * 100, 2) : 0;
        
        // 日过夜出租率
        $dayOvernightOccRate = $salableRooms > 0 ? round(($dayOvernightRooms / $salableRooms) * 100, 2) : 0;
        
        // 日均价 ADR = 日房费收入 / 日出租总间数
        $dayAdr = $dayTotalRooms > 0 ? round($dayRoomRevenue / $dayTotalRooms, 2) : 0;
        
        // 日Revpar = 日房费收入 / 可售房间数
        $dayRevpar = $salableRooms > 0 ? round($dayRoomRevenue / $salableRooms, 2) : 0;
        
        // OTA总量
        $otaTotalRooms = $xbRooms + $mtRooms + $fliggyRooms + $dyRooms + $tcRooms + $qnRooms + $zxRooms;
        
        // 日好评数
        $dayGoodReview = $xbGoodReview + $mtGoodReview + $fliggyGoodReview;
        $dayBadReview = $xbBadReview + $mtBadReview + $fliggyBadReview;
        
        // ===== 月累计计算 =====
        
        // 月线上收入
        $monthOnlineRevenue = $getVal($monthSum, 'xb_revenue') + $getVal($monthSum, 'mt_revenue') + 
                              $getVal($monthSum, 'fliggy_revenue') + $getVal($monthSum, 'dy_revenue') + 
                              $getVal($monthSum, 'tc_revenue') + $getVal($monthSum, 'qn_revenue') + 
                              $getVal($monthSum, 'zx_revenue');
        
        // 月线下收入
        $monthOfflineRevenue = $getVal($monthSum, 'walkin_revenue') + $getVal($monthSum, 'member_exp_revenue') + 
                               $getVal($monthSum, 'web_exp_revenue') + $getVal($monthSum, 'group_revenue') + 
                               $getVal($monthSum, 'protocol_revenue') + $getVal($monthSum, 'wechat_revenue') + 
                               $getVal($monthSum, 'free_revenue') + $getVal($monthSum, 'gold_card_revenue') + 
                               $getVal($monthSum, 'black_gold_revenue') + $getVal($monthSum, 'hourly_revenue');
        
        // 月其他收入
        $monthOtherRevenue = $getVal($monthSum, 'parking_revenue') + $getVal($monthSum, 'dining_revenue') + 
                             $getVal($monthSum, 'meeting_revenue') + $getVal($monthSum, 'goods_revenue') + 
                             $getVal($monthSum, 'member_card_revenue') + $getVal($monthSum, 'other_revenue');
        
        // 月房费收入
        $monthRoomRevenue = $monthOnlineRevenue + $monthOfflineRevenue;
        
        // 月总营收
        $monthTotalRevenue = $monthRoomRevenue + $monthOtherRevenue;
        
        // 月出租总间数
        $monthTotalRooms = $getVal($monthSum, 'xb_rooms') + $getVal($monthSum, 'mt_rooms') + 
                           $getVal($monthSum, 'fliggy_rooms') + $getVal($monthSum, 'dy_rooms') + 
                           $getVal($monthSum, 'tc_rooms') + $getVal($monthSum, 'qn_rooms') + 
                           $getVal($monthSum, 'zx_rooms') + $getVal($monthSum, 'walkin_rooms') + 
                           $getVal($monthSum, 'member_exp_rooms') + $getVal($monthSum, 'web_exp_rooms') + 
                           $getVal($monthSum, 'group_rooms') + $getVal($monthSum, 'protocol_rooms') + 
                           $getVal($monthSum, 'wechat_rooms') + $getVal($monthSum, 'free_rooms') + 
                           $getVal($monthSum, 'gold_card_rooms') + $getVal($monthSum, 'black_gold_rooms');
        
        // 月综合出租率
        $monthOccRate = $totalRooms > 0 && $day > 0 ? 
                        round(($monthTotalRooms / ($totalRooms * $day)) * 100, 2) : 0;
        
        // 月均价
        $monthAdr = $monthTotalRooms > 0 ? round($monthRoomRevenue / $monthTotalRooms, 2) : 0;
        
        // 月Revpar
        $monthRevpar = $totalRooms > 0 && $day > 0 ? 
                       round($monthRoomRevenue / ($totalRooms * $day), 2) : 0;
        
        // ===== 月任务目标 =====
        
        $monthRevenueTarget = $getVal($taskData, 'revenue_budget', 0);
        $monthOccTarget = $getVal($taskData, 'occupancy_rate_target', 0);
        $monthOtaTarget = $getVal($taskData, 'ota_total_orders', 0);
        $monthOnlineTarget = $getVal($taskData, 'online_revenue_target', 0);
        $monthOfflineTarget = $getVal($taskData, 'offline_revenue_target', 0);
        $monthNewMemberTarget = $getVal($taskData, 'new_members', 0);
        $monthWechatTarget = $getVal($taskData, 'wechat_new_friends', 0);
        
        // 月完成率
        $monthCompleteRate = $monthRevenueTarget > 0 ? 
                             round(($monthTotalRevenue / $monthRevenueTarget) * 100, 2) : 0;
        
        // 月营收差额
        $monthRevenueDiff = $monthTotalRevenue - $monthRevenueTarget;
        
        // 日目标（月目标/月天数）
        $dayRevenueTarget = $monthRevenueTarget > 0 ? round($monthRevenueTarget / $monthDays, 2) : 0;
        $dayRevenueDiff = $dayTotalRevenue - $dayRevenueTarget;
        
        // 月累计会员数
        $monthNewMembers = $getVal($monthSum, 'member_card_sold');
        $monthWechatAdd = $getVal($monthSum, 'wechat_add');
        
        // 月私域数据
        $monthPrivateRevenue = $getVal($monthSum, 'private_revenue');
        $monthPrivateRooms = $getVal($monthSum, 'private_rooms');
        $monthStoredValue = $getVal($monthSum, 'stored_value');
        
        // 私域占比
        $privateRate = $monthTotalRevenue > 0 ? 
                       round(($monthPrivateRevenue / $monthTotalRevenue) * 100, 2) : 0;
        
        // 月点评
        $monthGoodReview = $getVal($monthSum, 'xb_good_review') + $getVal($monthSum, 'mt_good_review') + 
                           $getVal($monthSum, 'fliggy_good_review');
        $monthBadReview = $getVal($monthSum, 'xb_bad_review') + $getVal($monthSum, 'mt_bad_review') + 
                          $getVal($monthSum, 'fliggy_bad_review');
        
        // 月免费房
        $monthFreeRooms = $getVal($monthSum, 'free_rooms');
        
        // 月现金收入
        $monthCashIncome = $getVal($monthSum, 'cash_income');
        
        // 构建返回数据
        return [
            'hotel_name' => $hotel->name,
            'report_date' => $reportDate,
            'total_rooms' => $totalRooms,
            'salable_rooms' => $salableRooms,
            'maintenance_rooms' => $totalRooms - $salableRooms,
            
            // 一、销售业绩
            'month_revenue_target' => $monthRevenueTarget,
            'month_revenue' => round($monthTotalRevenue, 2),
            'month_room_revenue' => round($monthRoomRevenue, 2),
            'month_other_revenue' => round($monthOtherRevenue, 2),
            'month_revenue_diff' => round($monthRevenueDiff, 2),
            'month_complete_rate' => $monthCompleteRate,
            
            'day_revenue_target' => $dayRevenueTarget,
            'day_revenue' => round($dayTotalRevenue, 2),
            'day_room_revenue' => round($dayRoomRevenue, 2),
            'day_other_revenue' => round($dayOtherRevenue, 2),
            'day_revenue_diff' => round($dayRevenueDiff, 2),
            
            'month_occ_rate' => $monthOccRate,
            'day_occ_rate' => $dayOccRate,
            'day_overnight_occ_rate' => $dayOvernightOccRate,
            
            'day_total_rooms' => (int)$dayTotalRooms,
            'day_overnight_rooms' => (int)$dayOvernightRooms,
            'day_hourly_rooms' => (int)$hourlyRooms,
            
            'month_adr' => $monthAdr,
            'day_adr' => $dayAdr,
            'overnight_adr' => $dayOvernightRooms > 0 ? 
                               round(($dayRoomRevenue - $hourlyRevenue) / $dayOvernightRooms, 2) : 0,
            
            'month_revpar' => $monthRevpar,
            'day_revpar' => $dayRevpar,
            
            'day_stored_value' => $storedValue,
            'month_stored_value' => $monthStoredValue,
            
            // 二、客源结构
            'member_count' => (int)$memberCardSold,
            'protocol_count' => (int)$protocolRooms,
            'walkin_count' => (int)$walkinRooms,
            'group_count' => (int)$groupRooms,
            'ota_total_rooms' => (int)$otaTotalRooms,
            'xb_rooms' => (int)$xbRooms,
            'mt_rooms' => (int)$mtRooms,
            'tc_rooms' => (int)$tcRooms,
            'qn_rooms' => (int)$qnRooms,
            'zx_rooms' => (int)$zxRooms,
            'fliggy_rooms' => (int)$fliggyRooms,
            'wechat_count' => (int)$wechatRooms,
            'dy_count' => (int)$dyRooms,
            'member_exp_rooms' => (int)$memberExpRooms,
            'web_exp_rooms' => (int)$webExpRooms,
            'free_rooms' => (int)$freeRooms,
            
            // 三、直销指标
            'day_new_member' => (int)$memberCardSold,
            'month_new_member_target' => $monthNewMemberTarget,
            'month_new_member' => (int)$monthNewMembers,
            'month_member_diff' => $monthNewMembers - $monthNewMemberTarget,
            
            'day_wechat_add' => (int)$wechatAdd,
            'month_wechat_target' => $monthWechatTarget,
            'month_wechat_add' => (int)$monthWechatAdd,
            'month_wechat_diff' => $monthWechatAdd - $monthWechatTarget,
            
            'day_private_rooms' => (int)$privateRooms,
            'day_private_revenue' => $privateRevenue,
            'month_private_rooms' => (int)$monthPrivateRooms,
            'month_private_revenue' => $monthPrivateRevenue,
            'private_rate' => $privateRate,
            
            // 四、OTA点评
            'day_good_review' => (int)$dayGoodReview,
            'day_bad_review' => (int)$dayBadReview,
            'month_good_review' => (int)$monthGoodReview,
            'month_bad_review' => (int)$monthBadReview,
            
            // 五、免费房
            'month_free_rooms' => (int)$monthFreeRooms,
            
            // 六、明日预订
            'tomorrow_booking' => (int)$tomorrowBooking,
            
            // 七、今日现金
            'day_cash_income' => $cashIncome,
            'month_cash_income' => $monthCashIncome,
            
            // 原始数据
            'raw_data' => $reportData,
        ];
    }

    /**
     * 创建日报表
     */
    public function create(): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_fill_daily_report');

        $data = $this->request->post();

        $this->validate($data, [
            'hotel_id' => 'require|integer',
            'report_date' => 'require|date',
        ], [
            'hotel_id.require' => '请选择酒店',
            'report_date.require' => '请选择日期',
        ]);

        $hotelId = (int)$data['hotel_id'];
        $reportDate = $data['report_date'];

        // 权限检查：用户是否有该酒店的填写权限
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($hotelId, 'can_fill_daily_report')) {
            return $this->error('您没有该酒店的日报填写权限');
        }

        // 验证日期：只能填写昨天及之前的日期
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        if ($reportDate > $yesterday) {
            return $this->error('只能填写昨天及之前的日报');
        }

        // 验证月任务：当月必须有月任务才能填写
        $dateParts = explode('-', $reportDate);
        $year = (int)$dateParts[0];
        $month = (int)$dateParts[1];

        $monthlyTask = MonthlyTask::where('hotel_id', $hotelId)
            ->where('year', $year)
            ->where('month', $month)
            ->find();
        
        if (!$monthlyTask) {
            return $this->error("请先添加 {$year}年{$month}月 的月任务，再填写日报");
        }

        // 检查是否已存在
        $exists = DailyReportModel::where('hotel_id', $hotelId)
            ->where('report_date', $reportDate)
            ->find();
        if ($exists) {
            return $this->error('该日期的报表已存在，请直接编辑');
        }

        // 提取报表数据（排除非报表字段）
        $reportData = $this->extractReportData($data);

        $report = new DailyReportModel();
        $report->hotel_id = $hotelId;
        $report->report_date = $reportDate;
        $report->report_data = $reportData;
        $report->submitter_id = $this->currentUser->id;
        $report->status = $data['status'] ?? DailyReportModel::STATUS_SUBMITTED;
        $report->save();

        OperationLog::record('daily_report', 'create', '创建日报表: ' . $report->report_date, $this->currentUser->id);

        return $this->success($report, '创建成功');
    }

    /**
     * 更新日报表
     */
    public function update(int $id): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_edit_report');

        $report = DailyReportModel::find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_edit_report')) {
            return $this->error('无权编辑此报表');
        }

        $data = $this->request->post();

        // 提取报表数据
        $reportData = $this->extractReportData($data);
        
        // 合并原有数据
        $existingData = $report->report_data ?? [];
        $report->report_data = array_merge($existingData, $reportData);
        
        if (isset($data['status'])) {
            $report->status = $data['status'];
        }
        $report->save();

        OperationLog::record('daily_report', 'update', '更新日报表: ' . $report->report_date, $this->currentUser->id);

        return $this->success($report, '更新成功');
    }

    /**
     * 删除日报表
     */
    public function delete(int $id): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_delete_report');

        $report = DailyReportModel::find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_delete_report')) {
            return $this->error('无权删除此报表');
        }

        $reportDate = $report->report_date;
        $report->delete();

        OperationLog::record('daily_report', 'delete', '删除日报表: ' . $reportDate, $this->currentUser->id);

        return $this->success(null, '删除成功');
    }

    /**
     * 提取报表数据（只保留配置中定义的字段）
     */
    private function extractReportData(array $data): array
    {
        // 获取所有配置的字段名
        $fieldNames = Db::table('report_configs')
            ->where('report_type', 'daily')
            ->where('status', 1)
            ->column('field_name');
        
        $reportData = [];
        foreach ($fieldNames as $field) {
            if (isset($data[$field])) {
                // 转换为数值类型（去除逗号等格式）
                $value = $data[$field];
                if (is_string($value)) {
                    $value = str_replace(',', '', $value);
                    $value = is_numeric($value) ? floatval($value) : $value;
                }
                $reportData[$field] = $value;
            }
        }
        
        return $reportData;
    }

    /**
     * 导出日报表到Excel
     */
    public function export(): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_view_report');

        $startDate = $this->request->get('start_date');
        $endDate = $this->request->get('end_date');
        $hotelId = $this->request->get('hotel_id');
        $reportId = $this->request->get('id');

        // 单个报表导出
        if ($reportId) {
            return $this->exportSingle((int)$reportId);
        }

        // 批量导出：验证用户对指定酒店的权限
        if ($hotelId && !$this->currentUser->isSuperAdmin()) {
            if (!$this->currentUser->hasHotelPermission((int)$hotelId, 'can_view_report')) {
                return $this->error('无权导出该酒店的报表');
            }
        }

        // 批量导出
        return $this->exportBatch($hotelId, $startDate, $endDate);
    }

    /**
     * 导出单个日报表
     */
    private function exportSingle(int $id): Response
    {
        $report = DailyReportModel::with(['hotel'])->find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }
        
        // 权限检查：用户是否有权限查看该酒店的报表
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_view_report')) {
            return $this->error('无权导出该报表');
        }
        
        $hotel = $report->hotel;
        $reportData = $report->report_data ?? [];
        $reportDate = $report->report_date;
        
        // 获取年月
        $dateParts = explode('-', $reportDate);
        $year = (int)$dateParts[0];
        $month = (int)$dateParts[1];
        $day = (int)$dateParts[2];
        $monthDays = (int)date('t', strtotime($reportDate));
        
        // 获取月任务
        $monthlyTask = MonthlyTask::where('hotel_id', $report->hotel_id)
            ->where('year', $year)
            ->where('month', $month)
            ->find();
        $taskData = $monthlyTask ? ($monthlyTask->task_data ?? []) : [];
        
        // 获取当月所有日报表数据
        $monthReports = DailyReportModel::where('hotel_id', $report->hotel_id)
            ->where('report_date', '>=', "{$year}-{$month}-01")
            ->where('report_date', '<=', $reportDate)
            ->select();
        
        // 计算月累计数据
        $monthSum = $this->calculateMonthSum($monthReports);
        
        // 准备导出数据 - 使用原始数据，与批量导出保持一致
        $exportData = [
            'mode' => 'single',
            'report' => [
                'hotel_name' => $hotel->name ?? '',
                'report_date' => $reportDate,
                'data' => $reportData,  // 直接传递原始数据
            ],
            'month_task' => $taskData,
        ];

        return $this->generateExcelResponse($exportData, "日报表_{$hotel->name}_{$reportDate}.xlsx");
    }

    /**
     * 批量导出日报表
     */
    private function exportBatch($hotelId, $startDate, $endDate): Response
    {
        $query = DailyReportModel::with('hotel');

        // 权限过滤
        if (!$this->currentUser->isSuperAdmin()) {
            $hotelIds = $this->currentUser->hotelPermissions->column('hotel_id');
            $query->whereIn('hotel_id', $hotelIds);
        }

        if ($hotelId) {
            $query->where('hotel_id', $hotelId);
        }

        if ($startDate) {
            $query->where('report_date', '>=', $startDate);
        }

        if ($endDate) {
            $query->where('report_date', '<=', $endDate);
        }

        $reports = $query->order('report_date', 'asc')->select();

        // 获取月任务数据
        $monthTaskData = [];
        if ($reports->count() > 0) {
            $firstReport = $reports[0];
            $dateParts = explode('-', $firstReport->report_date);
            $year = (int)$dateParts[0];
            $month = (int)$dateParts[1];
            
            $monthlyTask = MonthlyTask::where('hotel_id', $firstReport->hotel_id)
                ->where('year', $year)
                ->where('month', $month)
                ->find();
            
            if ($monthlyTask) {
                $monthTaskData = $monthlyTask->task_data ?? [];
            }
        }

        $exportData = [
            'reports' => [],
            'month_task' => $monthTaskData,
        ];
        
        // 获取酒店名称用于文件名
        $hotelName = '';
        if ($hotelId) {
            $hotel = Hotel::find($hotelId);
            if ($hotel) {
                $hotelName = $hotel->name;
            }
        }

        foreach ($reports as $report) {
            $reportData = $report->report_data ?? [];
            
            // 如果没有通过hotelId获取酒店名称，从第一条报表获取
            if (!$hotelName && $report->hotel) {
                $hotelName = $report->hotel->name;
            }
            
            $exportData['reports'][] = [
                'hotel_name' => $report->hotel->name ?? '',
                'report_date' => $report->report_date,
                'data' => $reportData,  // 直接传递原始数据，Excel公式会计算
            ];
        }

        // 生成文件名，包含酒店名称
        $filename = '日报表';
        if ($hotelName) {
            $filename .= "_{$hotelName}";
        }
        if ($startDate && $endDate) {
            $filename .= "_{$startDate}_{$endDate}";
        }
        $filename .= '.xlsx';

        return $this->generateExcelResponse($exportData, $filename);
    }

    /**
     * 调用Python脚本生成Excel并返回响应
     */
    private function generateExcelResponse(array $exportData, string $filename): Response
    {
        $scriptPath = root_path() . 'scripts/export_daily_report.py';
        $jsonData = json_encode($exportData, JSON_UNESCAPED_UNICODE);

        // 调用Python脚本
        $command = sprintf('python3 %s %s', escapeshellarg($scriptPath), escapeshellarg($jsonData));
        $output = shell_exec($command);

        if (!$output) {
            return $this->error('Excel生成失败');
        }

        $result = json_decode($output, true);
        if (isset($result['error'])) {
            return $this->error('Excel生成失败: ' . $result['error']);
        }

        if (!isset($result['data'])) {
            return $this->error('Excel生成失败: 无数据');
        }

        // 解码base64数据
        $excelData = base64_decode($result['data']);

        // 返回Excel文件
        return response($excelData, 200, [
            'Content-Type' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition' => 'attachment; filename="' . urlencode($filename) . '"',
            'Content-Length' => strlen($excelData),
        ]);
    }

    /**
     * 检查权限
     */
    private function checkPermission(): void
    {
        if (!$this->currentUser) {
            abort(401, '未登录');
        }
    }

    /**
     * 检查操作权限
     */
    private function checkActionPermission(string $permission): void
    {
        if ($this->currentUser->isSuperAdmin()) {
            return;
        }
        
        foreach ($this->currentUser->hotelPermissions as $perm) {
            if ($perm->$permission) {
                return;
            }
        }
        
        abort(403, '无权限操作');
    }
}
