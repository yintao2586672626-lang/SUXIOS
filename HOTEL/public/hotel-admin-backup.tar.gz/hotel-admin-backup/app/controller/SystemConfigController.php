<?php
declare(strict_types=1);

namespace app\controller;

use app\model\SystemConfig;
use app\model\OperationLog;
use think\Response;

class SystemConfigController extends Base
{
    /**
     * 获取所有系统配置
     */
    public function index(): Response
    {
        $this->checkPermission();

        $configs = SystemConfig::getAllConfigs();
        $defaults = SystemConfig::getDefaultConfigs();

        // 合并默认值
        foreach ($defaults as $key => $value) {
            if (!isset($configs[$key])) {
                $configs[$key] = $value;
            }
        }

        return $this->success($configs);
    }

    /**
     * 更新系统配置
     */
    public function update(): Response
    {
        $this->checkSuperAdmin();

        $data = $this->request->post();
        
        $descriptions = [
            SystemConfig::KEY_SYSTEM_NAME => '系统名称',
            SystemConfig::KEY_LOGO_URL => '系统Logo',
            SystemConfig::KEY_MENU_HOTEL => '酒店管理菜单名',
            SystemConfig::KEY_MENU_USERS => '用户管理菜单名',
            SystemConfig::KEY_MENU_DAILY_REPORT => '日报表管理菜单名',
            SystemConfig::KEY_MENU_MONTHLY_TASK => '月任务管理菜单名',
            SystemConfig::KEY_MENU_REPORT_CONFIG => '报表配置菜单名',
        ];

        foreach ($data as $key => $value) {
            if (isset($descriptions[$key])) {
                SystemConfig::setValue($key, $value, $descriptions[$key]);
            }
        }

        OperationLog::record('system_config', 'update', '更新系统配置', $this->currentUser->id);

        return $this->success(SystemConfig::getAllConfigs(), '配置更新成功');
    }

    /**
     * 检查权限
     */
    private function checkPermission(): void
    {
        if (!$this->currentUser) {
            abort(401, '未登录');
        }
    }

    /**
     * 检查超级管理员权限
     */
    private function checkSuperAdmin(): void
    {
        if (!$this->currentUser) {
            abort(401, '未登录');
        }

        if (!$this->currentUser->isSuperAdmin()) {
            abort(403, '无权限操作');
        }
    }
}
