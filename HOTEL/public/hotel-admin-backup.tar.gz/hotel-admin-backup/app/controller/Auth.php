<?php
declare(strict_types=1);

namespace app\controller;

use app\model\User;
use app\model\OperationLog;
use think\exception\ValidateException;
use think\Response;

class Auth extends Base
{
    /**
     * 登录
     */
    public function login(): Response
    {
        $username = $this->request->post('username', '');
        $password = $this->request->post('password', '');

        if (empty($username) || empty($password)) {
            return $this->error('用户名和密码不能为空');
        }

        $user = User::with(['role', 'hotel'])->where('username', $username)->find();
        if (!$user) {
            return $this->error('用户不存在');
        }

        if (!$user->verifyPassword($password)) {
            return $this->error('密码错误');
        }

        if ($user->status != User::STATUS_ENABLED) {
            return $this->error('账号已被禁用');
        }

        // 更新登录信息
        $user->last_login_time = date('Y-m-d H:i:s');
        $user->last_login_ip = $this->request->ip();
        $user->save();

        // 生成 Token（简化版，实际项目应使用 JWT）
        $token = md5($user->id . time() . uniqid());
        cache('token_' . $token, $user->id, 86400); // 缓存24小时

        OperationLog::record('auth', 'login', '用户登录: ' . $username, $user->id);

        return $this->success([
            'token' => $token,
            'user' => [
                'id' => $user->id,
                'username' => $user->username,
                'realname' => $user->realname,
                'role_id' => $user->role_id,
                'role_name' => $user->role ? $user->role->display_name : '',
                'hotel_id' => $user->hotel_id,
                'hotel_name' => $user->hotel ? $user->hotel->name : '',
                'is_super_admin' => $user->isSuperAdmin(),
            ],
        ], '登录成功');
    }

    /**
     * 登出
     */
    public function logout(): Response
    {
        $token = $this->request->header('Authorization', '');
        if ($token) {
            cache('token_' . $token, null);
        }
        return $this->success(null, '登出成功');
    }

    /**
     * 获取当前用户信息
     */
    public function info(): Response
    {
        if (!$this->currentUser) {
            return $this->error('未登录', 401);
        }

        $user = User::with(['role', 'hotel', 'hotelPermissions.hotel'])->find($this->currentUser->id);

        // 获取用户可访问的酒店
        $permittedHotels = [];
        $userPermissions = [];
        
        if ($user->isSuperAdmin()) {
            $permittedHotels = \app\model\Hotel::where('status', 1)->select();
            // 超级管理员拥有所有权限
            $userPermissions = [
                'can_view_report' => true,
                'can_fill_daily_report' => true,
                'can_fill_monthly_task' => true,
                'can_edit_report' => true,
                'can_delete_report' => true,
            ];
        } else {
            foreach ($user->hotelPermissions as $perm) {
                if ($perm->hotel) {
                    $permittedHotels[] = $perm->hotel;
                }
            }
            // 普通用户：合并所有酒店的权限（只要有一个酒店有该权限就认为有该权限）
            $hasView = false;
            $hasFillDaily = false;
            $hasFillMonthly = false;
            $hasEdit = false;
            $hasDelete = false;
            
            foreach ($user->hotelPermissions as $perm) {
                if ($perm->can_view_report) $hasView = true;
                if ($perm->can_fill_daily_report) $hasFillDaily = true;
                if ($perm->can_fill_monthly_task) $hasFillMonthly = true;
                if ($perm->can_edit_report) $hasEdit = true;
                if ($perm->can_delete_report) $hasDelete = true;
            }
            
            $userPermissions = [
                'can_view_report' => $hasView,
                'can_fill_daily_report' => $hasFillDaily,
                'can_fill_monthly_task' => $hasFillMonthly,
                'can_edit_report' => $hasEdit,
                'can_delete_report' => $hasDelete,
            ];
        }

        return $this->success([
            'id' => $user->id,
            'username' => $user->username,
            'realname' => $user->realname,
            'email' => $user->email,
            'phone' => $user->phone,
            'role_id' => $user->role_id,
            'role_name' => $user->role ? $user->role->display_name : '',
            'hotel_id' => $user->hotel_id,
            'hotel' => $user->hotel,
            'is_super_admin' => $user->isSuperAdmin(),
            'is_hotel_manager' => $user->isHotelManager(),
            'permitted_hotels' => $permittedHotels,
            'permissions' => $userPermissions,
        ]);
    }

    /**
     * 修改密码
     */
    public function changePassword(): Response
    {
        if (!$this->currentUser) {
            return $this->error('未登录', 401);
        }

        $oldPassword = $this->request->post('old_password', '');
        $newPassword = $this->request->post('new_password', '');

        if (strlen($newPassword) < 6) {
            return $this->error('新密码长度至少6位');
        }

        $user = User::find($this->currentUser->id);
        if (!$user->verifyPassword($oldPassword)) {
            return $this->error('原密码错误');
        }

        $user->password = $newPassword;
        $user->save();

        OperationLog::record('auth', 'change_password', '修改密码', $user->id);

        return $this->success(null, '密码修改成功');
    }
}
