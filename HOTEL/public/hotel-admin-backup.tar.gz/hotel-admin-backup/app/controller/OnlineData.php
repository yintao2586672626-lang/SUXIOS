<?php
declare(strict_types=1);

namespace app\controller;

use app\model\OperationLog;
use think\Response;
use think\facade\Db;

class OnlineData extends Base
{
    /**
     * 获取线上数据 - 携程ebooking接口
     */
    public function fetchCtrip(): Response
    {
        $this->checkPermission();
        
        $url = $this->request->post('url', 'https://ebooking.ctrip.com/datacenter/api/dataCenter/report/getDayReportCompeteHotelReport');
        $nodeId = $this->request->post('node_id', '24588');
        $cookies = $this->request->post('cookies', '');
        $startDate = $this->request->post('start_date', '');
        $endDate = $this->request->post('end_date', '');
        $autoSave = $this->request->post('auto_save', true); // 默认自动保存
        
        if (empty($cookies)) {
            return $this->error('请提供登录Cookies');
        }
        
        try {
            // 构建请求参数
            $postData = [
                'nodeId' => $nodeId,
            ];
            
            if ($startDate && $endDate) {
                $postData['startDate'] = $startDate;
                $postData['endDate'] = $endDate;
            } else {
                // 默认获取昨天的数据
                $yesterday = date('Y-m-d', strtotime('-1 day'));
                $postData['startDate'] = $yesterday;
                $postData['endDate'] = $yesterday;
                $startDate = $yesterday;
            }
            
            // 发送请求
            $result = $this->sendHttpRequest($url, $postData, $cookies);
            
            if (!$result['success']) {
                return $this->error('请求失败: ' . $result['error']);
            }
            
            $responseData = $result['data'];
            $savedCount = 0;
            
            // 自动保存数据到数据库
            if ($autoSave) {
                $savedCount = $this->parseAndSaveData($responseData, $startDate, $endDate);
            }
            
            OperationLog::record('online_data', 'fetch_ctrip', '获取携程线上数据', $this->currentUser->id);
            
            return $this->success([
                'data' => $responseData,
                'raw_response' => $result['raw'],
                'saved_count' => $savedCount,
            ]);
        } catch (\Exception $e) {
            return $this->error('请求异常: ' . $e->getMessage());
        }
    }
    
    /**
     * 解析并保存数据到数据库
     */
    private function parseAndSaveData($responseData, $startDate, $endDate): int
    {
        $dataList = [];
        
        // 尝试多种数据结构解析
        // 结构1: { data: { hotelList: [...] } }
        if (isset($responseData['data']['hotelList']) && is_array($responseData['data']['hotelList'])) {
            $dataList = $responseData['data']['hotelList'];
        }
        // 结构2: { data: [...] }
        elseif (isset($responseData['data']) && is_array($responseData['data']) && !isset($responseData['data'][0])) {
            // data 是对象，继续查找
            foreach ($responseData['data'] as $key => $value) {
                if (is_array($value) && isset($value[0]) && isset($value[0]['hotelId'])) {
                    $dataList = array_merge($dataList, $value);
                }
            }
        }
        // 结构3: { data: [...] } 直接是数组
        elseif (isset($responseData['data']) && is_array($responseData['data']) && isset($responseData['data'][0])) {
            $dataList = $responseData['data'];
        }
        // 结构4: { hotelList: [...] }
        elseif (isset($responseData['hotelList']) && is_array($responseData['hotelList'])) {
            $dataList = $responseData['hotelList'];
        }
        // 结构5: { Response: { hotelList: [...] } }
        elseif (isset($responseData['Response']['hotelList']) && is_array($responseData['Response']['hotelList'])) {
            $dataList = $responseData['Response']['hotelList'];
        }
        // 结构6: 直接是数组
        elseif (is_array($responseData) && isset($responseData[0])) {
            $dataList = $responseData;
        }
        // 结构7: 遍历所有字段查找酒店数据
        else {
            $dataList = $this->extractHotelData($responseData);
        }
        
        if (empty($dataList)) {
            return 0;
        }
        
        $savedCount = 0;
        $dataDate = $startDate ?: date('Y-m-d', strtotime('-1 day'));
        
        foreach ($dataList as $item) {
            if (!is_array($item)) continue;
            
            // 尝试多种字段名获取酒店ID
            $hotelId = $item['hotelId'] ?? $item['hotel_id'] ?? $item['HotelId'] ?? $item['hotelID'] ?? null;
            if (empty($hotelId)) continue;
            
            // 尝试多种字段名获取酒店名称
            $hotelName = $item['hotelName'] ?? $item['hotel_name'] ?? $item['HotelName'] ?? $item['name'] ?? '';
            
            // 尝试多种字段名获取其他数据
            $amount = floatval($item['amount'] ?? $item['Amount'] ?? $item['totalAmount'] ?? $item['total_amount'] ?? $item['saleAmount'] ?? 0);
            $quantity = intval($item['quantity'] ?? $item['Quantity'] ?? $item['roomNights'] ?? $item['room_nights'] ?? $item['checkOutQuantity'] ?? 0);
            $bookOrderNum = intval($item['bookOrderNum'] ?? $item['book_order_num'] ?? $item['orderCount'] ?? $item['order_count'] ?? 0);
            $commentScore = floatval($item['commentScore'] ?? $item['comment_score'] ?? $item['score'] ?? $item['avgScore'] ?? 0);
            $qunarCommentScore = floatval($item['qunarCommentScore'] ?? $item['qunar_comment_score'] ?? $item['qunarScore'] ?? 0);
            
            // 如果有日期字段，使用它
            $itemDate = $item['dataDate'] ?? $item['date'] ?? $item['data_date'] ?? $dataDate;
            
            // 检查是否已存在
            $exists = Db::name('online_daily_data')
                ->where('hotel_id', (string)$hotelId)
                ->where('data_date', $itemDate)
                ->find();
            
            $data = [
                'hotel_id' => (string)$hotelId,
                'hotel_name' => $hotelName,
                'data_date' => $itemDate,
                'amount' => $amount,
                'quantity' => $quantity,
                'book_order_num' => $bookOrderNum,
                'comment_score' => $commentScore,
                'qunar_comment_score' => $qunarCommentScore,
                'raw_data' => json_encode($item, JSON_UNESCAPED_UNICODE),
            ];
            
            if ($exists) {
                Db::name('online_daily_data')
                    ->where('id', $exists['id'])
                    ->update($data);
            } else {
                Db::name('online_daily_data')->insert($data);
            }
            $savedCount++;
        }
        
        return $savedCount;
    }
    
    /**
     * 递归提取酒店数据
     */
    private function extractHotelData($data): array
    {
        $result = [];
        
        if (!is_array($data)) {
            return $result;
        }
        
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                // 检查是否是酒店数据项
                if (isset($value['hotelId']) || isset($value['hotel_id']) || isset($value['HotelId'])) {
                    $result[] = $value;
                } elseif (isset($value[0]) && is_array($value[0])) {
                    // 递归查找
                    $result = array_merge($result, $this->extractHotelData($value));
                }
            }
        }
        
        return $result;
    }
    
    /**
     * 获取线上数据 - 自定义URL
     */
    public function fetchCustom(): Response
    {
        $this->checkPermission();
        
        $url = $this->request->post('url', '');
        $method = $this->request->post('method', 'GET');
        $headers = $this->request->post('headers', '');
        $body = $this->request->post('body', '');
        
        if (empty($url)) {
            return $this->error('请提供URL');
        }
        
        try {
            $result = $this->sendCustomRequest($url, $method, $headers, $body);
            
            if ($result['success']) {
                OperationLog::record('online_data', 'fetch_custom', '获取自定义线上数据: ' . $url, $this->currentUser->id);
                return $this->success([
                    'data' => $result['data'],
                    'status' => $result['status'],
                    'headers' => $result['response_headers'],
                ]);
            } else {
                return $this->error('请求失败: ' . $result['error']);
            }
        } catch (\Exception $e) {
            return $this->error('请求异常: ' . $e->getMessage());
        }
    }
    
    /**
     * 接收来自书签脚本的Cookies（跨域请求）
     * 不需要常规认证，通过URL中的token识别用户
     */
    public function receiveCookies(): Response
    {
        // 允许跨域请求
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        
        if ($this->request->method() === 'OPTIONS') {
            return response('', 204);
        }
        
        $token = $this->request->param('token', '');
        $name = $this->request->post('name', 'ctrip_auto');
        $cookies = $this->request->post('cookies', '');
        $source = $this->request->post('source', '');
        
        if (empty($token)) {
            return $this->corsError('缺少认证Token');
        }
        
        if (empty($cookies)) {
            return $this->corsError('Cookies内容为空');
        }
        
        // 验证token
        $userId = cache('token_' . $token);
        if (!$userId) {
            return $this->corsError('Token无效或已过期');
        }
        
        // 保存Cookies配置
        $key = 'online_data_cookies_list';
        $list = cache($key) ?: [];
        $list[$name] = [
            'name' => $name,
            'cookies' => $cookies,
            'source' => $source,
            'update_time' => date('Y-m-d H:i:s'),
            'user_id' => $userId,
        ];
        cache($key, $list, 86400 * 365);
        
        OperationLog::record('online_data', 'receive_cookies', '通过书签脚本获取Cookies: ' . $name, (int)$userId);
        
        return $this->corsSuccess([
            'name' => $name,
            'message' => 'Cookies已成功保存到系统',
        ]);
    }
    
    /**
     * 返回CORS错误响应
     */
    private function corsError(string $message): Response
    {
        return json([
            'code' => 400,
            'message' => $message,
            'data' => null,
        ])->header([
            'Access-Control-Allow-Origin' => '*',
        ]);
    }
    
    /**
     * 返回CORS成功响应
     */
    private function corsSuccess(array $data): Response
    {
        return json([
            'code' => 200,
            'message' => '操作成功',
            'data' => $data,
        ])->header([
            'Access-Control-Allow-Origin' => '*',
        ]);
    }
    
    /**
     * 获取书签脚本代码
     */
    public function bookmarklet(): Response
    {
        $this->checkPermission();
        
        $token = $this->request->get('token', '');
        if (empty($token)) {
            return $this->error('缺少Token');
        }
        
        // 获取完整的 baseUrl（包含协议）
        $scheme = $this->request->scheme(); // http 或 https
        $host = $this->request->host(true);
        $baseUrl = $scheme . '://' . $host;
        
        // 生成书签脚本
        $script = <<<JAVASCRIPT
(function(){
    var t='{$token}';
    var u='{$baseUrl}';
    var c=document.cookie;
    var n=prompt('请输入Cookies配置名称:','ctrip_'+new Date().toLocaleDateString().replace(/\//g,'-'));
    if(!n)return;
    var s=document.location.href;
    var d=new FormData();
    d.append('name',n);
    d.append('cookies',c);
    d.append('source',s);
    fetch(u+'/api/online-data/receive-cookies?token='+t,{
        method:'POST',
        body:d,
        mode:'cors'
    }).then(r=>r.json()).then(j=>{
        if(j.code===200){
            alert('Cookies已成功保存: '+n);
        }else{
            alert('保存失败: '+j.message);
        }
    }).catch(e=>alert('请求失败: '+e.message));
})();
JAVASCRIPT;
        
        // 压缩脚本
        $script = preg_replace('/\s+/', ' ', $script);
        
        return $this->success([
            'script' => $script,
            'bookmarklet' => 'javascript:' . $script,
            'instructions' => [
                '1. 将下面的按钮拖拽到浏览器书签栏',
                '2. 在携程ebooking页面登录后，点击该书签',
                '3. 输入配置名称，Cookies将自动保存到系统',
            ],
        ]);
    }
    
    /**
     * 保存Cookies配置
     */
    public function saveCookies(): Response
    {
        $this->checkPermission();
        
        $name = $this->request->post('name', '');
        $cookies = $this->request->post('cookies', '');
        
        if (empty($name) || empty($cookies)) {
            return $this->error('名称和Cookies不能为空');
        }
        
        // 使用缓存存储Cookies配置
        $key = 'online_data_cookies_list';
        $list = cache($key) ?: [];
        $list[$name] = [
            'name' => $name,
            'cookies' => $cookies,
            'update_time' => date('Y-m-d H:i:s'),
        ];
        cache($key, $list, 86400 * 365); // 缓存一年
        
        return $this->success(null, 'Cookies保存成功');
    }
    
    /**
     * 获取已保存的Cookies列表
     */
    public function getCookiesList(): Response
    {
        $this->checkPermission();
        
        $key = 'online_data_cookies_list';
        $list = cache($key) ?: [];
        
        return $this->success(array_values($list));
    }
    
    /**
     * 删除Cookies配置
     */
    public function deleteCookies(): Response
    {
        $this->checkPermission();
        
        $name = $this->request->post('name', '');
        
        if (empty($name)) {
            return $this->error('名称不能为空');
        }
        
        $key = 'online_data_cookies_list';
        $list = cache($key) ?: [];
        if (isset($list[$name])) {
            unset($list[$name]);
            cache($key, $list, 86400 * 365);
        }
        
        return $this->success(null, '删除成功');
    }
    
    /**
     * 发送HTTP请求到携程ebooking（使用file_get_contents）
     */
    private function sendHttpRequest(string $url, array $postData, string $cookies): array
    {
        $headers = [
            'Accept: application/json, text/javascript, */*; q=0.01',
            'Accept-Language: zh-CN,zh;q=0.9,en;q=0.8',
            'Content-Type: application/x-www-form-urlencoded; charset=UTF-8',
            'X-Requested-With: XMLHttpRequest',
            'Origin: https://ebooking.ctrip.com',
            'Referer: https://ebooking.ctrip.com/',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Cookie: ' . $cookies,
        ];
        
        $headerStr = implode("\r\n", $headers);
        
        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => $headerStr,
                'content' => http_build_query($postData),
                'timeout' => 30,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ]);
        
        $response = @file_get_contents($url, false, $context);
        
        if ($response === false) {
            $error = error_get_last();
            return [
                'success' => false,
                'error' => $error['message'] ?? 'Unknown error',
            ];
        }
        
        $decoded = json_decode($response, true);
        
        return [
            'success' => true,
            'data' => $decoded,
            'raw' => $response,
        ];
    }
    
    /**
     * 发送自定义HTTP请求（使用file_get_contents）
     */
    private function sendCustomRequest(string $url, string $method, string $headersStr, string $body): array
    {
        $headers = [];
        if (!empty($headersStr)) {
            $headerLines = explode("\n", $headersStr);
            foreach ($headerLines as $line) {
                $line = trim($line);
                if (!empty($line)) {
                    $headers[] = $line;
                }
            }
        }
        
        $headerStr = implode("\r\n", $headers);
        
        $options = [
            'http' => [
                'method' => strtoupper($method),
                'header' => $headerStr,
                'timeout' => 30,
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
            ],
        ];
        
        if (strtoupper($method) === 'POST' && !empty($body)) {
            $options['http']['content'] = $body;
        }
        
        $context = stream_context_create($options);
        
        $response = @file_get_contents($url, false, $context);
        
        if ($response === false) {
            $error = error_get_last();
            return [
                'success' => false,
                'error' => $error['message'] ?? 'Unknown error',
            ];
        }
        
        // 获取响应头
        $responseHeaders = '';
        $status = 200;
        if (isset($http_response_header)) {
            $responseHeaders = implode("\r\n", $http_response_header);
            // 解析HTTP状态码
            if (preg_match('/HTTP\/\d+\.?\d*\s+(\d+)/', $http_response_header[0] ?? '', $matches)) {
                $status = (int)$matches[1];
            }
        }
        
        $decoded = json_decode($response, true);
        
        return [
            'success' => true,
            'data' => $decoded,
            'raw' => $response,
            'status' => $status,
            'response_headers' => $responseHeaders,
        ];
    }
    
    /**
     * 检查权限
     */
    private function checkPermission(): void
    {
        if (!$this->currentUser) {
            abort(401, '未登录');
        }
    }
    
    /**
     * 保存线上数据到数据库
     */
    public function saveDailyData(): Response
    {
        $this->checkPermission();
        
        $dataList = $this->request->post('data', []);
        $dataDate = $this->request->post('data_date', date('Y-m-d', strtotime('-1 day')));
        
        if (empty($dataList)) {
            return $this->error('数据不能为空');
        }
        
        // 使用统一的解析和保存方法
        $savedCount = $this->parseAndSaveData(['data' => $dataList], $dataDate, $dataDate);
        
        OperationLog::record('online_data', 'save_daily', '保存线上数据: ' . $savedCount . '条', $this->currentUser->id);
        
        return $this->success(['saved_count' => $savedCount], '保存成功，共保存 ' . $savedCount . ' 条数据');
    }
    
    /**
     * 获取线上数据列表
     */
    public function dailyDataList(): Response
    {
        $this->checkPermission();
        
        $startDate = $this->request->get('start_date', date('Y-m-d', strtotime('-30 days')));
        $endDate = $this->request->get('end_date', date('Y-m-d'));
        $hotelId = $this->request->get('hotel_id', '');
        $page = intval($this->request->get('page', 1));
        $pageSize = intval($this->request->get('page_size', 20));
        
        $query = Db::name('online_daily_data')
            ->where('data_date', '>=', $startDate)
            ->where('data_date', '<=', $endDate);
        
        if (!empty($hotelId)) {
            $query->where('hotel_id', $hotelId);
        }
        
        $total = $query->count();
        $list = $query->order('data_date', 'desc')
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select()
            ->toArray();
        
        return $this->success([
            'list' => $list,
            'pagination' => [
                'total' => $total,
                'page' => $page,
                'page_size' => $pageSize,
            ],
        ]);
    }
    
    /**
     * 获取数据统计汇总
     */
    public function dailyDataSummary(): Response
    {
        $this->checkPermission();
        
        $startDate = $this->request->get('start_date', date('Y-m-d', strtotime('-7 days')));
        $endDate = $this->request->get('end_date', date('Y-m-d'));
        
        // 按日期汇总
        $dailySummary = Db::name('online_daily_data')
            ->field('data_date, SUM(amount) as total_amount, SUM(quantity) as total_quantity, SUM(book_order_num) as total_book_order_num, AVG(comment_score) as avg_comment_score')
            ->where('data_date', '>=', $startDate)
            ->where('data_date', '<=', $endDate)
            ->group('data_date')
            ->order('data_date', 'desc')
            ->select()
            ->toArray();
        
        // 总计
        $totalSummary = Db::name('online_daily_data')
            ->field('SUM(amount) as total_amount, SUM(quantity) as total_quantity, SUM(book_order_num) as total_book_order_num, AVG(comment_score) as avg_comment_score')
            ->where('data_date', '>=', $startDate)
            ->where('data_date', '<=', $endDate)
            ->find();
        
        return $this->success([
            'daily' => $dailySummary,
            'total' => $totalSummary,
        ]);
    }
    
    /**
     * 获取酒店列表（用于筛选）
     */
    public function hotelList(): Response
    {
        $this->checkPermission();
        
        $hotels = Db::name('online_daily_data')
            ->field('hotel_id, MAX(hotel_name) as hotel_name')
            ->group('hotel_id')
            ->select()
            ->toArray();
        
        return $this->success($hotels);
    }
    
    /**
     * 自动获取并保存数据（供定时任务调用）
     */
    public function autoFetch(): Response
    {
        // 获取携程 cookies 配置
        $cookiesList = cache('online_data_cookies_list') ?: [];
        $cookies = '';
        foreach ($cookiesList as $item) {
            if (strpos($item['name'], 'ctrip') !== false) {
                $cookies = $item['cookies'];
                break;
            }
        }
        
        if (empty($cookies)) {
            return $this->error('未配置携程Cookies');
        }
        
        // 获取昨天的数据
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        
        try {
            $result = $this->sendHttpRequest(
                'https://ebooking.ctrip.com/datacenter/api/dataCenter/report/getDayReportCompeteHotelReport',
                ['nodeId' => '24588', 'startDate' => $yesterday, 'endDate' => $yesterday],
                $cookies
            );
            
            if (!$result['success']) {
                return $this->error('请求失败: ' . $result['error']);
            }
            
            $responseData = $result['data'];
            
            // 使用统一的数据解析和保存方法
            $savedCount = $this->parseAndSaveData($responseData, $yesterday, $yesterday);
            
            if ($savedCount === 0) {
                return $this->error('未获取到有效数据，请检查Cookies是否有效');
            }
            
            OperationLog::record('online_data', 'auto_fetch', '自动获取并保存线上数据: ' . $savedCount . '条', 0);
            
            // 更新最后运行状态
            $status = cache('online_data_auto_fetch_status') ?: [];
            $status['last_run_time'] = date('Y-m-d H:i:s');
            $status['last_result'] = [
                'success' => true,
                'message' => '成功获取 ' . $savedCount . ' 条数据'
            ];
            cache('online_data_auto_fetch_status', $status, 86400 * 30);
            
            return $this->success(['saved_count' => $savedCount], '自动获取成功');
            
        } catch (\Exception $e) {
            // 更新错误状态
            $status = cache('online_data_auto_fetch_status') ?: [];
            $status['last_run_time'] = date('Y-m-d H:i:s');
            $status['last_result'] = [
                'success' => false,
                'message' => '获取失败: ' . $e->getMessage()
            ];
            cache('online_data_auto_fetch_status', $status, 86400 * 30);
            
            return $this->error('异常: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取自动获取状态
     */
    public function autoFetchStatus(): Response
    {
        $this->checkPermission();
        
        $status = cache('online_data_auto_fetch_status') ?: [
            'enabled' => true,
            'last_run_time' => null,
            'next_run_time' => '每天 10:00',
            'last_result' => null
        ];
        
        // 确保 enabled 字段存在
        if (!isset($status['enabled'])) {
            $status['enabled'] = true;
        }
        $status['next_run_time'] = '每天 10:00';
        
        return $this->success($status);
    }
    
    /**
     * 切换自动获取开关
     */
    public function toggleAutoFetch(): Response
    {
        $this->checkPermission();
        
        $enabled = $this->request->post('enabled', true);
        
        $status = cache('online_data_auto_fetch_status') ?: [];
        $status['enabled'] = (bool)$enabled;
        cache('online_data_auto_fetch_status', $status, 86400 * 30);
        
        OperationLog::record('online_data', 'toggle_auto_fetch', '切换自动获取状态: ' . ($enabled ? '开启' : '关闭'), $this->currentUser->id);
        
        return $this->success(['enabled' => $status['enabled']], $enabled ? '已开启自动获取' : '已关闭自动获取');
    }
}
