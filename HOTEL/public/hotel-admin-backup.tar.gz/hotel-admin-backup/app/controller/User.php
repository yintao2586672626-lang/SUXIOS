<?php
declare(strict_types=1);

namespace app\controller;

use app\model\User as UserModel;
use app\model\Role;
use app\model\Hotel;
use app\model\UserHotelPermission;
use app\model\OperationLog;
use think\exception\ValidateException;
use think\Response;
use think\facade\Db;

class User extends Base
{
    /**
     * 用户列表
     */
    public function index(): Response
    {
        $this->checkPermission();

        $pagination = $this->getPagination();
        $username = $this->request->param('username', '');
        $roleId = $this->request->param('role_id', '');
        $status = $this->request->param('status', '');
        $hotelId = $this->request->param('hotel_id', '');

        $query = UserModel::with(['role', 'hotel'])->order('id', 'desc');

        if ($username) {
            $query->whereLike('username', '%' . $username . '%');
        }
        if ($roleId) {
            $query->where('role_id', $roleId);
        }
        if ($status !== '') {
            $query->where('status', $status);
        }
        if ($hotelId) {
            $query->where('hotel_id', $hotelId);
        }

        // 非超级管理员只能看到自己酒店的用户
        if (!$this->currentUser->isSuperAdmin()) {
            $permittedHotelIds = $this->currentUser->getPermittedHotelIds();
            $query->whereIn('hotel_id', $permittedHotelIds);
        }

        $total = $query->count();
        $list = $query->page($pagination['page'], $pagination['page_size'])->select()->hidden(['password']);

        return $this->paginate($list, $total, $pagination['page'], $pagination['page_size']);
    }

    /**
     * 用户详情
     */
    public function read(int $id): Response
    {
        $this->checkPermission();

        $user = UserModel::with(['role', 'hotel', 'hotelPermissions.hotel'])->find($id);
        if (!$user) {
            return $this->error('用户不存在');
        }

        $user->hidden(['password']);
        return $this->success($user);
    }

    /**
     * 创建用户
     */
    public function create(): Response
    {
        $this->checkPermission(true);

        $data = $this->request->post();

        $this->validate($data, [
            'username' => 'require|alphaNum|min:3|max:20',
            'password' => 'require|min:6',
            'role_id' => 'require|integer',
        ], [
            'username.require' => '用户名不能为空',
            'username.alphaNum' => '用户名只能包含字母和数字',
            'username.min' => '用户名至少3个字符',
            'username.max' => '用户名最多20个字符',
            'password.require' => '密码不能为空',
            'password.min' => '密码至少6个字符',
            'role_id.require' => '请选择角色',
        ]);

        // 检查用户名唯一性
        $exists = UserModel::where('username', $data['username'])->find();
        if ($exists) {
            return $this->error('用户名已存在');
        }

        Db::startTrans();
        try {
            $user = new UserModel();
            $user->username = $data['username'];
            $user->password = $data['password'];
            $user->realname = $data['realname'] ?? '';
            $user->email = $data['email'] ?? '';
            $user->phone = $data['phone'] ?? '';
            $user->role_id = $data['role_id'];
            $user->hotel_id = $data['hotel_id'] ?? null;
            $user->status = $data['status'] ?? UserModel::STATUS_ENABLED;
            $user->save();

            // 保存酒店权限
            if (!empty($data['hotel_permissions']) && is_array($data['hotel_permissions'])) {
                foreach ($data['hotel_permissions'] as $perm) {
                    if (empty($perm['hotel_id'])) continue;
                    
                    $permission = new UserHotelPermission();
                    $permission->user_id = $user->id;
                    $permission->hotel_id = $perm['hotel_id'];
                    $permission->can_view_report = $perm['can_view_report'] ?? 0;
                    $permission->can_fill_daily_report = $perm['can_fill_daily_report'] ?? 0;
                    $permission->can_fill_monthly_task = $perm['can_fill_monthly_task'] ?? 0;
                    $permission->can_edit_report = $perm['can_edit_report'] ?? 0;
                    $permission->can_delete_report = $perm['can_delete_report'] ?? 0;
                    $permission->is_primary = ($user->hotel_id == $perm['hotel_id']) ? 1 : 0;
                    $permission->save();
                }
            }

            Db::commit();
            OperationLog::record('user', 'create', '创建用户: ' . $user->username, $this->currentUser->id);

            return $this->success($user->hidden(['password']), '创建成功');
        } catch (\Exception $e) {
            Db::rollback();
            return $this->error('创建失败: ' . $e->getMessage());
        }
    }

    /**
     * 更新用户
     */
    public function update(int $id): Response
    {
        $this->checkPermission();

        $user = UserModel::find($id);
        if (!$user) {
            return $this->error('用户不存在');
        }

        // 权限检查：只有超级管理员可以修改其他用户
        if (!$this->currentUser->isSuperAdmin() && $this->currentUser->id != $id) {
            abort(403, '权限不足');
        }

        $data = $this->request->post();

        // 用户名唯一性检查
        if (!empty($data['username']) && $data['username'] != $user->username) {
            $exists = UserModel::where('username', $data['username'])->find();
            if ($exists) {
                return $this->error('用户名已存在');
            }
            $user->username = $data['username'];
        }

        if (!empty($data['password'])) {
            if (strlen($data['password']) < 6) {
                return $this->error('密码至少6个字符');
            }
            $user->password = $data['password'];
        }

        $user->realname = $data['realname'] ?? $user->realname;
        $user->email = $data['email'] ?? $user->email;
        $user->phone = $data['phone'] ?? $user->phone;

        // 只有超级管理员可以修改角色和酒店
        if ($this->currentUser->isSuperAdmin()) {
            $user->role_id = $data['role_id'] ?? $user->role_id;
            $user->hotel_id = $data['hotel_id'] ?? $user->hotel_id;
            if (isset($data['status'])) {
                $user->status = $data['status'];
            }

            // 更新酒店权限
            if (isset($data['hotel_permissions']) && is_array($data['hotel_permissions'])) {
                // 删除旧权限
                UserHotelPermission::where('user_id', $id)->delete();
                
                // 添加新权限
                foreach ($data['hotel_permissions'] as $perm) {
                    if (empty($perm['hotel_id'])) continue;
                    
                    $permission = new UserHotelPermission();
                    $permission->user_id = $user->id;
                    $permission->hotel_id = $perm['hotel_id'];
                    $permission->can_view_report = $perm['can_view_report'] ?? 0;
                    $permission->can_fill_daily_report = $perm['can_fill_daily_report'] ?? 0;
                    $permission->can_fill_monthly_task = $perm['can_fill_monthly_task'] ?? 0;
                    $permission->can_edit_report = $perm['can_edit_report'] ?? 0;
                    $permission->can_delete_report = $perm['can_delete_report'] ?? 0;
                    $permission->is_primary = ($user->hotel_id == $perm['hotel_id']) ? 1 : 0;
                    $permission->save();
                }
            }
        }

        $user->save();

        OperationLog::record('user', 'update', '更新用户: ' . $user->username, $this->currentUser->id);

        return $this->success($user->hidden(['password']), '更新成功');
    }

    /**
     * 删除用户
     */
    public function delete(int $id): Response
    {
        $this->checkPermission(true);

        if ($id == $this->currentUser->id) {
            return $this->error('不能删除自己');
        }

        $user = UserModel::find($id);
        if (!$user) {
            return $this->error('用户不存在');
        }

        $username = $user->username;
        
        // 删除用户权限
        UserHotelPermission::where('user_id', $id)->delete();
        $user->delete();

        OperationLog::record('user', 'delete', '删除用户: ' . $username, $this->currentUser->id);

        return $this->success(null, '删除成功');
    }

    /**
     * 角色列表
     */
    public function roles(): Response
    {
        $roles = Role::where('status', 1)->order('level', 'asc')->select();
        return $this->success($roles);
    }

    /**
     * 更新用户酒店权限
     */
    public function updatePermissions(int $id): Response
    {
        $this->checkPermission(true);

        $user = UserModel::find($id);
        if (!$user) {
            return $this->error('用户不存在');
        }

        $data = $this->request->post();
        
        if (!isset($data['permissions']) || !is_array($data['permissions'])) {
            return $this->error('权限数据格式错误');
        }

        Db::startTrans();
        try {
            foreach ($data['permissions'] as $perm) {
                if (empty($perm['hotel_id'])) continue;

                $permission = UserHotelPermission::where('user_id', $id)
                    ->where('hotel_id', $perm['hotel_id'])
                    ->find();

                if (!$permission) {
                    $permission = new UserHotelPermission();
                    $permission->user_id = $id;
                    $permission->hotel_id = $perm['hotel_id'];
                }

                $permission->can_view_report = $perm['can_view_report'] ?? 0;
                $permission->can_fill_daily_report = $perm['can_fill_daily_report'] ?? 0;
                $permission->can_fill_monthly_task = $perm['can_fill_monthly_task'] ?? 0;
                $permission->can_edit_report = $perm['can_edit_report'] ?? 0;
                $permission->can_delete_report = $perm['can_delete_report'] ?? 0;
                $permission->is_primary = $perm['is_primary'] ?? 0;
                $permission->save();
            }

            Db::commit();
            OperationLog::record('user', 'update_permissions', '更新用户权限: ' . $user->username, $this->currentUser->id);

            return $this->success(null, '权限更新成功');
        } catch (\Exception $e) {
            Db::rollback();
            return $this->error('权限更新失败: ' . $e->getMessage());
        }
    }

    /**
     * 获取用户的酒店权限
     */
    public function permissions(int $id): Response
    {
        $this->checkPermission();

        $user = UserModel::find($id);
        if (!$user) {
            return $this->error('用户不存在');
        }

        // 超级管理员拥有所有酒店的所有权限
        if ($user->isSuperAdmin()) {
            $hotels = Hotel::where('status', 1)->select();
            $permissions = [];
            foreach ($hotels as $hotel) {
                $permissions[] = [
                    'hotel_id' => $hotel->id,
                    'hotel_name' => $hotel->name,
                    'can_view_report' => 1,
                    'can_fill_daily_report' => 1,
                    'can_fill_monthly_task' => 1,
                    'can_edit_report' => 1,
                    'can_delete_report' => 1,
                    'is_primary' => ($user->hotel_id == $hotel->id) ? 1 : 0,
                ];
            }
            return $this->success($permissions);
        }

        // 获取用户的具体权限
        $permissions = UserHotelPermission::with('hotel')
            ->where('user_id', $id)
            ->select();

        $result = [];
        foreach ($permissions as $perm) {
            $result[] = [
                'hotel_id' => $perm->hotel_id,
                'hotel_name' => $perm->hotel ? $perm->hotel->name : '',
                'can_view_report' => $perm->can_view_report,
                'can_fill_daily_report' => $perm->can_fill_daily_report,
                'can_fill_monthly_task' => $perm->can_fill_monthly_task,
                'can_edit_report' => $perm->can_edit_report,
                'can_delete_report' => $perm->can_delete_report,
                'is_primary' => $perm->is_primary,
            ];
        }

        return $this->success($result);
    }

    /**
     * 检查权限
     */
    private function checkPermission(bool $requireAdmin = false): void
    {
        if (!$this->currentUser) {
            abort(401, '未登录');
        }

        if ($requireAdmin && !$this->currentUser->isSuperAdmin()) {
            abort(403, '权限不足');
        }
    }
}
