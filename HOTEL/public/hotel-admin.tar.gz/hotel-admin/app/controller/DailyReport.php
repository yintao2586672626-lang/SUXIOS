<?php
declare(strict_types=1);

namespace app\controller;

use app\model\DailyReport as DailyReportModel;
use app\model\MonthlyTask;
use app\model\Hotel;
use app\model\OperationLog;
use think\exception\ValidateException;
use think\Response;
use think\facade\Db;

class DailyReport extends Base
{
    /**
     * 获取报表配置
     */
    public function config(): Response
    {
        $this->checkPermission();
        
        // 获取日报表配置，按分类分组
        $configs = Db::table('report_configs')
            ->where('report_type', 'daily')
            ->where('status', 1)
            ->order('sort_order', 'asc')
            ->select()
            ->toArray();
        
        // 按分类分组
        $groupedConfigs = [];
        foreach ($configs as $config) {
            $category = $config['category'];
            if (!isset($groupedConfigs[$category])) {
                $groupedConfigs[$category] = [
                    'category' => $category,
                    'items' => []
                ];
            }
            $groupedConfigs[$category]['items'][] = [
                'id' => $config['id'],
                'field_name' => $config['field_name'],
                'display_name' => $config['display_name'],
                'field_type' => $config['field_type'],
                'unit' => $config['unit'],
                'sort_order' => $config['sort_order'],
                'is_required' => $config['is_required'],
            ];
        }
        
        // 转为索引数组
        $result = array_values($groupedConfigs);
        
        return $this->success($result);
    }

    /**
     * 日报表列表
     */
    public function index(): Response
    {
        $this->checkPermission();

        $pagination = $this->getPagination();
        $hotelId = $this->request->param('hotel_id', '');
        $startDate = $this->request->param('start_date', '');
        $endDate = $this->request->param('end_date', '');

        $query = DailyReportModel::with(['hotel', 'submitter'])->order('id', 'desc');

        // 根据权限过滤酒店
        if (!$this->currentUser->isSuperAdmin()) {
            $permittedHotelIds = $this->currentUser->getPermittedHotelIds();
            if (empty($permittedHotelIds)) {
                return $this->paginate([], 0, $pagination['page'], $pagination['page_size']);
            }
            if ($hotelId && in_array($hotelId, $permittedHotelIds)) {
                $query->where('hotel_id', $hotelId);
            } else {
                $query->whereIn('hotel_id', $permittedHotelIds);
            }
        } elseif ($hotelId) {
            $query->where('hotel_id', $hotelId);
        }

        if ($startDate && $endDate) {
            $query->whereBetween('report_date', [$startDate, $endDate]);
        } elseif ($startDate) {
            $query->where('report_date', '>=', $startDate);
        } elseif ($endDate) {
            $query->where('report_date', '<=', $endDate);
        }

        $total = $query->count();
        $list = $query->page($pagination['page'], $pagination['page_size'])->select();

        return $this->paginate($list, $total, $pagination['page'], $pagination['page_size']);
    }

    /**
     * 日报表详情
     */
    public function read(int $id): Response
    {
        $this->checkPermission();

        $report = DailyReportModel::with(['hotel', 'submitter'])->find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_view_report')) {
            return $this->error('无权查看此报表');
        }

        return $this->success($report);
    }

    /**
     * 创建日报表
     */
    public function create(): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_fill_daily_report');

        $data = $this->request->post();

        $this->validate($data, [
            'hotel_id' => 'require|integer',
            'report_date' => 'require|date',
        ], [
            'hotel_id.require' => '请选择酒店',
            'report_date.require' => '请选择日期',
        ]);

        $hotelId = (int)$data['hotel_id'];
        $reportDate = $data['report_date'];

        // 权限检查：用户是否有该酒店的填写权限
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($hotelId, 'can_fill_daily_report')) {
            return $this->error('您没有该酒店的日报填写权限');
        }

        // 验证日期：只能填写昨天及之前的日期
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        if ($reportDate > $yesterday) {
            return $this->error('只能填写昨天及之前的日报');
        }

        // 验证月任务：当月必须有月任务才能填写
        $dateParts = explode('-', $reportDate);
        $year = (int)$dateParts[0];
        $month = (int)$dateParts[1];

        $monthlyTask = MonthlyTask::where('hotel_id', $hotelId)
            ->where('year', $year)
            ->where('month', $month)
            ->find();
        
        if (!$monthlyTask) {
            return $this->error("请先添加 {$year}年{$month}月 的月任务，再填写日报");
        }

        // 检查是否已存在
        $exists = DailyReportModel::where('hotel_id', $hotelId)
            ->where('report_date', $reportDate)
            ->find();
        if ($exists) {
            return $this->error('该日期的报表已存在，请直接编辑');
        }

        // 提取报表数据（排除非报表字段）
        $reportData = $this->extractReportData($data);

        $report = new DailyReportModel();
        $report->hotel_id = $hotelId;
        $report->report_date = $reportDate;
        $report->report_data = $reportData;
        $report->submitter_id = $this->currentUser->id;
        $report->status = $data['status'] ?? DailyReportModel::STATUS_SUBMITTED;
        $report->save();

        OperationLog::record('daily_report', 'create', '创建日报表: ' . $report->report_date, $this->currentUser->id);

        return $this->success($report, '创建成功');
    }

    /**
     * 更新日报表
     */
    public function update(int $id): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_edit_report');

        $report = DailyReportModel::find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_edit_report')) {
            return $this->error('无权编辑此报表');
        }

        $data = $this->request->post();

        // 提取报表数据
        $reportData = $this->extractReportData($data);
        
        // 合并原有数据
        $existingData = $report->report_data ?? [];
        $report->report_data = array_merge($existingData, $reportData);
        
        if (isset($data['status'])) {
            $report->status = $data['status'];
        }
        $report->save();

        OperationLog::record('daily_report', 'update', '更新日报表: ' . $report->report_date, $this->currentUser->id);

        return $this->success($report, '更新成功');
    }

    /**
     * 删除日报表
     */
    public function delete(int $id): Response
    {
        $this->checkPermission();
        $this->checkActionPermission('can_delete_report');

        $report = DailyReportModel::find($id);
        if (!$report) {
            return $this->error('报表不存在');
        }

        // 权限检查
        if (!$this->currentUser->isSuperAdmin() && !$this->currentUser->hasHotelPermission($report->hotel_id, 'can_delete_report')) {
            return $this->error('无权删除此报表');
        }

        $reportDate = $report->report_date;
        $report->delete();

        OperationLog::record('daily_report', 'delete', '删除日报表: ' . $reportDate, $this->currentUser->id);

        return $this->success(null, '删除成功');
    }

    /**
     * 提取报表数据（只保留配置中定义的字段）
     */
    private function extractReportData(array $data): array
    {
        // 获取所有配置的字段名
        $fieldNames = Db::table('report_configs')
            ->where('report_type', 'daily')
            ->where('status', 1)
            ->column('field_name');
        
        $reportData = [];
        foreach ($fieldNames as $field) {
            if (isset($data[$field])) {
                // 转换为数值类型（去除逗号等格式）
                $value = $data[$field];
                if (is_string($value)) {
                    $value = str_replace(',', '', $value);
                    $value = is_numeric($value) ? floatval($value) : $value;
                }
                $reportData[$field] = $value;
            }
        }
        
        return $reportData;
    }

    /**
     * 检查权限
     */
    private function checkPermission(): void
    {
        if (!$this->currentUser) {
            abort(401, '未登录');
        }
    }

    /**
     * 检查操作权限
     */
    private function checkActionPermission(string $permission): void
    {
        if ($this->currentUser->isSuperAdmin()) {
            return;
        }
        
        foreach ($this->currentUser->hotelPermissions as $perm) {
            if ($perm->$permission) {
                return;
            }
        }
        
        abort(403, '无权限操作');
    }
}
